import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Search, 
  Star, 
  Clock, 
  User, 
  ArrowLeft,
  TrendingUp,
  Award,
  DollarSign,
  Home,
  Lightbulb,
  Shield,
  Thermometer,
  Speaker
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const smartHomeReviews = [
  {
    id: 1,
    title: "Amazon Echo Dot (5th Gen): Smart Home Starter",
    brand: "Amazon",
    model: "Echo Dot 5th Gen",
    price: "$49",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1519558260268-cde7e03a0152?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydCUyMGhvbWUlMjBkZXZpY2VzfGVufDF8fHx8MTc1ODIwODA3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Amazon's compact smart speaker delivers excellent Alexa functionality and smart home control at an affordable price...",
    pros: ["Very affordable", "Great Alexa integration", "Compact design"],
    cons: ["Average sound quality", "Privacy concerns", "Requires internet"],
    author: "Sarah Johnson",
    readTime: "8 min read",
    category: "Smart Speaker",
    featured: true
  },
  {
    id: 2,
    title: "Nest Thermostat: Smart Climate Control",
    brand: "Google",
    model: "Nest Learning Thermostat",
    price: "$249",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1545259741-2ea3ebf61fa9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhOZXN0JTIwdGhlcm1vc3RhdCUyMHNtYXJ0fGVufDF8fHx8MTc1ODIxOTQyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Google's intelligent thermostat learns your schedule and preferences to optimize energy usage and comfort...",
    pros: ["Learns your schedule", "Energy savings", "Beautiful design"],
    cons: ["Expensive installation", "Complex setup", "Requires C-wire"],
    author: "Mike Rodriguez",
    readTime: "10 min read",
    category: "Climate"
  },
  {
    id: 3,
    title: "Philips Hue: Premium Smart Lighting",
    brand: "Philips",
    model: "Hue Color Starter Kit",
    price: "$199",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1556075798-4825dfaaf498?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQaGlsaXBzJTIwSHVlJTIwc21hcnQlMjBsaWdodHN8ZW58MXx8fHwxNzU4MjE5NDIyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Philips Hue offers the best smart lighting experience with millions of colors and seamless integration...",
    pros: ["Excellent color range", "Great app experience", "Reliable connectivity"],
    cons: ["Very expensive", "Requires hub", "Complex for beginners"],
    author: "Tech Reviewer",
    readTime: "11 min read",
    category: "Lighting"
  },
  {
    id: 4,
    title: "Ring Video Doorbell Pro 2: Security Enhanced",
    brand: "Ring",
    model: "Video Doorbell Pro 2",
    price: "$279",
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxSaW5nJTIwZG9vcmJlbGwlMjBzZWN1cml0eXxlbnwxfHx8fDE3NTgyMTk0MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Ring's premium video doorbell offers enhanced security features with 1536p video and advanced motion detection...",
    pros: ["High-quality video", "Advanced motion zones", "Package detection"],
    cons: ["Subscription required", "Installation complexity", "Privacy concerns"],
    author: "David Kim",
    readTime: "9 min read",
    category: "Security"
  }
];

const buyingGuides = [
  {
    id: 1,
    title: "Smart Home Starter Guide",
    description: "Essential devices for smart home beginners",
    icon: Home,
    color: "bg-blue-500"
  },
  {
    id: 2,
    title: "Smart Lighting Systems",
    description: "Complete guide to smart bulbs and switches",
    icon: Lightbulb,
    color: "bg-yellow-500"
  },
  {
    id: 3,
    title: "Home Security Setup",
    description: "Cameras, doorbells, and security systems",
    icon: Shield,
    color: "bg-red-500"
  },
  {
    id: 4,
    title: "Climate Control Guide",
    description: "Smart thermostats and HVAC automation",
    icon: Thermometer,
    color: "bg-green-500"
  },
  {
    id: 5,
    title: "Smart Speaker Comparison",
    description: "Alexa vs Google vs Apple ecosystem",
    icon: Speaker,
    color: "bg-purple-500"
  },
  {
    id: 6,
    title: "Budget Smart Home Setup",
    description: "Great smart home gear under $200",
    icon: DollarSign,
    color: "bg-orange-500"
  }
];

interface SmartHomePageProps {
  onBack: () => void;
}

export function SmartHomePage({ onBack }: SmartHomePageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredReviews = smartHomeReviews.filter(review => {
    const matchesSearch = review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === "all" || review.brand.toLowerCase() === selectedBrand;
    const matchesCategory = selectedCategory === "all" || review.category.toLowerCase().replace(" ", "") === selectedCategory;
    
    return matchesSearch && matchesBrand && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Smart Home</h1>
                <p className="text-sm text-muted-foreground">Latest smart home device reviews and guides</p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              {smartHomeReviews.length} Reviews
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="reviews" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reviews">Latest Reviews</TabsTrigger>
            <TabsTrigger value="guides">Buying Guides</TabsTrigger>
            <TabsTrigger value="comparisons">Comparisons</TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-8">
            {/* Filters */}
            <div className="flex flex-col md:flex-row gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search smart home devices..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedBrand} onValueChange={setSelectedBrand}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  <SelectItem value="amazon">Amazon</SelectItem>
                  <SelectItem value="google">Google</SelectItem>
                  <SelectItem value="philips">Philips</SelectItem>
                  <SelectItem value="ring">Ring</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="smartspeaker">Smart Speaker</SelectItem>
                  <SelectItem value="lighting">Lighting</SelectItem>
                  <SelectItem value="security">Security</SelectItem>
                  <SelectItem value="climate">Climate</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Reviews Grid */}
            <div className="grid lg:grid-cols-2 gap-8">
              {filteredReviews.map((review, index) => (
                <Card key={review.id} className={`overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1 ${index === 0 ? 'lg:col-span-2' : ''}`}>
                  <div className={`${index === 0 ? 'aspect-[16/9]' : 'aspect-[4/3]'} relative overflow-hidden`}>
                    <ImageWithFallback 
                      src={review.image}
                      alt={review.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className="bg-black/80 text-white">
                        {review.brand}
                      </Badge>
                      <Badge variant="secondary">
                        {review.category}
                      </Badge>
                      {review.featured && (
                        <Badge className="bg-red-500 text-white">
                          Featured
                        </Badge>
                      )}
                    </div>
                    <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {review.price}
                    </div>
                  </div>
                  <CardContent className={`${index === 0 ? 'p-8' : 'p-6'}`}>
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${
                              i < Math.floor(review.rating) 
                                ? 'fill-yellow-400 text-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium">{review.rating}/5</span>
                    </div>
                    <h3 className={`${index === 0 ? 'text-2xl' : 'text-lg'} font-semibold mb-3 group-hover:text-primary transition-colors`}>
                      {review.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 line-clamp-2">{review.excerpt}</p>
                    
                    {/* Pros & Cons */}
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <h5 className="text-sm font-medium text-green-600 mb-2">Pros</h5>
                        <ul className="text-xs space-y-1">
                          {review.pros.slice(0, 2).map((pro, i) => (
                            <li key={i} className="text-muted-foreground">• {pro}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-red-600 mb-2">Cons</h5>
                        <ul className="text-xs space-y-1">
                          {review.cons.slice(0, 2).map((con, i) => (
                            <li key={i} className="text-muted-foreground">• {con}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{review.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{review.readTime}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">Read Full Review</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guides" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold mb-2">Smart Home Buying Guides</h2>
              <p className="text-muted-foreground">Expert advice to help you build the perfect smart home</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {buyingGuides.map((guide) => {
                const IconComponent = guide.icon;
                return (
                  <Card key={guide.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                    <CardContent className="p-6 text-center">
                      <div className={`${guide.color} text-white rounded-full p-4 w-16 h-16 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <IconComponent className="h-8 w-8" />
                      </div>
                      <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                        {guide.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        {guide.description}
                      </p>
                      <Button variant="outline" size="sm">Read Guide</Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="comparisons">
            <div className="text-center py-16">
              <h2 className="text-2xl font-semibold mb-2">Smart Home Comparisons</h2>
              <p className="text-muted-foreground mb-8">Coming soon - detailed smart home device comparisons</p>
              <Button>Request a Comparison</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}