import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Search, 
  Filter, 
  Star, 
  Clock, 
  User, 
  ArrowLeft,
  TrendingUp,
  Award,
  DollarSign,
  Zap,
  Battery,
  Camera,
  Cpu,
  Smartphone
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const smartphoneReviews = [
  {
    id: 1,
    title: "iPhone 15 Pro Max Review: The Camera King",
    brand: "Apple",
    model: "iPhone 15 Pro Max",
    price: "$1,199",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1743677221330-9886caa74fcc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpUGhvbmUlMjAxNSUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzU4MjE4ODQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Apple's flagship delivers exceptional camera performance and titanium build quality that sets new standards for premium smartphones...",
    fullReview: "The iPhone 15 Pro Max represents Apple's most ambitious smartphone to date, featuring a revolutionary titanium design and the most advanced camera system ever in an iPhone. The A17 Pro chip delivers desktop-class performance while maintaining excellent battery life. The new Action Button replaces the mute switch, offering customizable functionality that power users will appreciate. Camera performance is truly exceptional, with the 48MP main sensor producing incredibly detailed photos in all lighting conditions.",
    specs: {
      display: "6.7-inch Super Retina XDR OLED",
      processor: "A17 Pro",
      ram: "8GB",
      storage: "256GB/512GB/1TB",
      camera: "48MP Triple Camera System",
      battery: "4441 mAh",
      os: "iOS 17"
    },
    pros: ["Outstanding camera system", "Premium titanium build", "Excellent performance", "Great battery life", "Smooth 120Hz display"],
    cons: ["Very expensive", "Limited charging speed", "No expandable storage", "Heavy weight"],
    author: "NextGadgets Team",
    readTime: "12 min read",
    category: "Flagship",
    featured: true,
    score: {
      design: 9.0,
      performance: 9.5,
      camera: 9.8,
      battery: 8.5,
      value: 7.0
    }
  },
  {
    id: 2,
    title: "Samsung Galaxy S24 Ultra: S Pen Powerhouse",
    brand: "Samsung",
    model: "Galaxy S24 Ultra",
    price: "$1,299",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1695048065031-ee3d2ce7ee89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTYW1zdW5nJTIwR2FsYXh5JTIwcGhvbmV8ZW58MXx8fHwxNzU4MjE4ODQ5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Samsung's Note successor combines S Pen functionality with flagship performance and AI features in a premium package...",
    fullReview: "The Galaxy S24 Ultra continues Samsung's tradition of excellence in the premium smartphone segment. The integrated S Pen remains the device's standout feature, offering precise input for note-taking, drawing, and productivity tasks. The Snapdragon 8 Gen 3 processor delivers exceptional performance, while the 200MP camera system captures stunning photos with incredible detail. The 6.8-inch Dynamic AMOLED display is simply gorgeous, with perfect color accuracy and brightness that excels even in direct sunlight.",
    specs: {
      display: "6.8-inch Dynamic AMOLED 2X",
      processor: "Snapdragon 8 Gen 3",
      ram: "12GB",
      storage: "256GB/512GB/1TB",
      camera: "200MP Quad Camera System",
      battery: "5000 mAh",
      os: "Android 14 with One UI 6.1"
    },
    pros: ["S Pen integration", "Excellent display", "Versatile cameras", "Great performance", "AI features"],
    cons: ["Battery life could be better", "Heavy and bulky", "Expensive", "S Pen slot reduces battery space"],
    author: "NextGadgets Team",
    readTime: "10 min read",
    category: "Flagship",
    score: {
      design: 8.5,
      performance: 9.2,
      camera: 9.0,
      battery: 8.0,
      value: 7.5
    }
  },
  {
    id: 3,
    title: "Google Pixel 8 Pro: AI Photography Champion",
    brand: "Google",
    model: "Pixel 8 Pro",
    price: "$999",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1567141579811-d507c3b05d02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxHb29nbGUlMjBQaXhlbCUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzU4MjE4ODQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Google's computational photography and AI features make this a standout flagship with the best camera software experience...",
    fullReview: "The Pixel 8 Pro showcases Google's mastery of computational photography and AI integration. The Tensor G3 chip powers incredible AI features like Magic Eraser, Best Take, and Audio Magic Eraser. The camera system, while not having the highest megapixel count, produces consistently excellent photos thanks to Google's advanced image processing. The clean Android experience with guaranteed 7 years of updates makes this a compelling long-term choice.",
    specs: {
      display: "6.7-inch LTPO OLED",
      processor: "Google Tensor G3",
      ram: "12GB",
      storage: "128GB/256GB/512GB/1TB",
      camera: "50MP Triple Camera System",
      battery: "5050 mAh",
      os: "Android 14"
    },
    pros: ["Best-in-class AI photos", "Clean Android experience", "7 years of updates", "Excellent night mode", "Great value"],
    cons: ["Average battery life", "Slower charging", "Tensor chip not fastest", "Limited availability"],
    author: "NextGadgets Team",
    readTime: "11 min read",
    category: "Flagship",
    score: {
      design: 8.0,
      performance: 8.5,
      camera: 9.5,
      battery: 7.5,
      value: 8.5
    }
  },
  {
    id: 4,
    title: "OnePlus 12: Speed Demon Returns",
    brand: "OnePlus",
    model: "OnePlus 12",
    price: "$799",
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1637190909375-85cd40d14161?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxPbmVQbHVzJTIwc21hcnRwaG9uZXxlbnwxfHx8fDE3NTgyMTg4NDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "OnePlus returns to its roots with flagship performance at a competitive price point and incredibly fast charging...",
    fullReview: "The OnePlus 12 marks a triumphant return to form for the brand, offering flagship performance at a more accessible price point. The Snapdragon 8 Gen 3 delivers blazing fast performance, while the 100W SuperVOOC charging can power the device from 0-100% in just 23 minutes. The camera system, developed in partnership with Hasselblad, shows significant improvements over previous generations with more natural color reproduction and better low-light performance.",
    specs: {
      display: "6.82-inch Fluid AMOLED",
      processor: "Snapdragon 8 Gen 3",
      ram: "12GB/16GB",
      storage: "256GB/512GB",
      camera: "50MP Triple Camera System",
      battery: "5400 mAh",
      os: "Android 14 with OxygenOS 14"
    },
    pros: ["Blazing fast performance", "Excellent value", "Super fast charging", "Great display", "Improved cameras"],
    cons: ["Software updates slower", "No wireless charging", "Limited availability", "OxygenOS changes"],
    author: "NextGadgets Team",
    readTime: "9 min read",
    category: "Performance",
    score: {
      design: 8.5,
      performance: 9.5,
      camera: 8.0,
      battery: 9.0,
      value: 9.0
    }
  },
  {
    id: 5,
    title: "Xiaomi 14 Ultra: Photography Beast",
    brand: "Xiaomi",
    model: "14 Ultra",
    price: "$1,099",
    rating: 4.4,
    image: "https://images.unsplash.com/photo-1726836584814-3c279642218b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHBob25lJTIwZGV2aWNlJTIwbG9nbyUyMG1vZGVybnxlbnwxfHx8fDE3NTgzMDUxMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Xiaomi's camera-focused flagship features Leica partnership and professional photography capabilities in a premium package...",
    fullReview: "The Xiaomi 14 Ultra represents the pinnacle of mobile photography with its Leica-engineered quad-camera system. The 50MP main sensor with variable aperture delivers exceptional versatility, while the dedicated telephoto lenses provide professional-grade zoom capabilities. The Snapdragon 8 Gen 3 ensures smooth performance, and the 90W fast charging keeps you powered throughout the day.",
    specs: {
      display: "6.73-inch LTPO AMOLED",
      processor: "Snapdragon 8 Gen 3",
      ram: "12GB/16GB",
      storage: "256GB/512GB/1TB",
      camera: "50MP Quad Camera System with Leica",
      battery: "5300 mAh",
      os: "Android 14 with HyperOS"
    },
    pros: ["Exceptional camera system", "Leica partnership", "Premium build quality", "Fast charging", "Great display"],
    cons: ["Expensive", "MIUI learning curve", "Limited software support", "Heavy device"],
    author: "NextGadgets Team",
    readTime: "10 min read",
    category: "Camera",
    score: {
      design: 8.5,
      performance: 9.0,
      camera: 9.5,
      battery: 8.5,
      value: 7.5
    }
  },
  {
    id: 6,
    title: "Nothing Phone (2a): Design Innovation",
    brand: "Nothing",
    model: "Phone (2a)",
    price: "$399",
    rating: 4.2,
    image: "https://images.unsplash.com/photo-1695048065031-ee3d2ce7ee89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTYW1zdW5nJTIwR2FsYXh5JTIwcGhvbmV8ZW58MXx8fHwxNzU4MjE4ODQ5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Nothing's unique transparent design and Glyph interface make this mid-range phone stand out from the crowd...",
    fullReview: "The Nothing Phone (2a) brings the brand's distinctive transparent design language to a more affordable price point. The Glyph interface on the back provides unique notification patterns and adds genuine functionality beyond just aesthetics. The MediaTek Dimensity 7200 Pro provides solid mid-range performance, while Nothing OS delivers a clean Android experience with thoughtful customizations.",
    specs: {
      display: "6.7-inch AMOLED",
      processor: "MediaTek Dimensity 7200 Pro",
      ram: "8GB/12GB",
      storage: "128GB/256GB",
      camera: "50MP Dual Camera System",
      battery: "5000 mAh",
      os: "Android 14 with Nothing OS 2.5"
    },
    pros: ["Unique transparent design", "Glyph interface", "Clean software", "Good value", "Solid build quality"],
    cons: ["Mid-range performance", "Limited availability", "Camera could be better", "No wireless charging"],
    author: "NextGadgets Team",
    readTime: "8 min read",
    category: "Mid-Range",
    score: {
      design: 9.5,
      performance: 7.5,
      camera: 7.0,
      battery: 8.0,
      value: 8.5
    }
  },
  {
    id: 7,
    title: "ASUS ROG Phone 8: Gaming Monster",
    brand: "ASUS",
    model: "ROG Phone 8",
    price: "$1,199",
    rating: 4.3,
    image: "https://images.unsplash.com/photo-1632387955207-feda3020ab1c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBjb25zb2xlJTIwY29udHJvbGxlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4Njh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "The ultimate gaming smartphone with advanced cooling, 165Hz display, and gaming-specific features for mobile esports...",
    fullReview: "The ROG Phone 8 is purpose-built for mobile gaming excellence. The Snapdragon 8 Gen 3 combined with up to 24GB of RAM ensures no game can challenge its performance. The 165Hz AMOLED display with 720Hz touch sampling rate provides the responsiveness serious gamers demand. Advanced cooling systems keep the device running at peak performance during extended gaming sessions.",
    specs: {
      display: "6.78-inch AMOLED 165Hz",
      processor: "Snapdragon 8 Gen 3",
      ram: "12GB/16GB/24GB",
      storage: "256GB/512GB/1TB",
      camera: "50MP Triple Camera System",
      battery: "6000 mAh",
      os: "Android 14 with ROG UI"
    },
    pros: ["Exceptional gaming performance", "165Hz display", "Massive battery", "Advanced cooling", "Gaming accessories"],
    cons: ["Bulky design", "Expensive", "Overkill for non-gamers", "Software updates slower"],
    author: "NextGadgets Team",
    readTime: "9 min read",
    category: "Gaming",
    score: {
      design: 7.5,
      performance: 10.0,
      camera: 7.5,
      battery: 9.5,
      value: 7.0
    }
  },
  {
    id: 8,
    title: "Motorola Edge 50 Pro: Balanced Excellence",
    brand: "Motorola",
    model: "Edge 50 Pro",
    price: "$599",
    rating: 4.1,
    image: "https://images.unsplash.com/photo-1637190909375-85cd40d14161?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxPbmVQbHVzJTIwc21hcnRwaG9uZXxlbnwxfHx8fDE3NTgyMTg4NDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Motorola delivers a well-rounded premium experience with clean software, solid cameras, and competitive pricing...",
    fullReview: "The Motorola Edge 50 Pro strikes an excellent balance between features and price. The Snapdragon 7 Gen 3 provides smooth performance for everyday tasks and light gaming. Motorola's near-stock Android experience is refreshing, with useful additions like Moto Actions gestures. The camera system performs admirably in most conditions, though it struggles in very low light compared to flagship competitors.",
    specs: {
      display: "6.7-inch pOLED 144Hz",
      processor: "Snapdragon 7 Gen 3",
      ram: "8GB/12GB",
      storage: "256GB/512GB",
      camera: "50MP Triple Camera System",
      battery: "4500 mAh",
      os: "Android 14"
    },
    pros: ["Clean Android experience", "Good performance", "Competitive pricing", "Solid build quality", "Useful Moto features"],
    cons: ["Camera struggles in low light", "Plastic back", "Average battery life", "Limited availability"],
    author: "NextGadgets Team",
    readTime: "7 min read",
    category: "Mid-Range",
    score: {
      design: 7.5,
      performance: 8.0,
      camera: 7.5,
      battery: 7.5,
      value: 8.5
    }
  }
];

const buyingGuides = [
  {
    id: 1,
    title: "Best Smartphones Under $500 (2025)",
    description: "Top budget phones that don't compromise on essentials",
    icon: DollarSign,
    color: "bg-green-500"
  },
  {
    id: 2,
    title: "Flagship Phone Comparison Guide",
    description: "iPhone vs Galaxy vs Pixel - detailed comparison",
    icon: Award,
    color: "bg-blue-500"
  },
  {
    id: 3,
    title: "Gaming Phone Buyer's Guide",
    description: "Best phones for mobile gaming performance",
    icon: Zap,
    color: "bg-purple-500"
  },
  {
    id: 4,
    title: "Camera Phone Photography Guide",
    description: "Best phones for photography enthusiasts",
    icon: Camera,
    color: "bg-red-500"
  },
  {
    id: 5,
    title: "Battery Life Champions",
    description: "Phones with the longest lasting batteries",
    icon: Battery,
    color: "bg-orange-500"
  },
  {
    id: 6,
    title: "Performance Powerhouses",
    description: "Fastest processors and smoothest experiences",
    icon: Cpu,
    color: "bg-indigo-500"
  }
];

interface SmartphonesPageProps {
  onBack: () => void;
}

export function SmartphonesPage({ onBack }: SmartphonesPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedReview, setSelectedReview] = useState<any>(null);

  const filteredReviews = smartphoneReviews.filter(review => {
    const matchesSearch = review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === "all" || review.brand.toLowerCase() === selectedBrand;
    const matchesCategory = selectedCategory === "all" || review.category.toLowerCase() === selectedCategory;
    
    return matchesSearch && matchesBrand && matchesCategory;
  });

  if (selectedReview) {
    return (
      <div className="min-h-screen bg-background">
        {/* Full Review View */}
        <div className="border-b bg-background/95 backdrop-blur sticky top-0 z-40">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => setSelectedReview(null)}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Badge variant="secondary">Full Review</Badge>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="aspect-[16/9] relative overflow-hidden rounded-xl mb-8">
              <ImageWithFallback 
                src={selectedReview.image}
                alt={selectedReview.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <Badge className="bg-black/80 text-white">{selectedReview.brand}</Badge>
                <Badge variant="secondary">{selectedReview.category}</Badge>
              </div>
              <div className="absolute bottom-4 right-4 bg-black/80 text-white px-4 py-2 rounded-full font-medium">
                {selectedReview.price}
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-4">{selectedReview.title}</h1>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground mb-6">
                  <div className="flex items-center space-x-1">
                    <User className="h-4 w-4" />
                    <span>{selectedReview.author}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{selectedReview.readTime}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${
                            i < Math.floor(selectedReview.rating) 
                              ? 'fill-yellow-400 text-yellow-400' 
                              : 'text-gray-300'
                          }`} 
                        />
                      ))}
                    </div>
                    <span className="font-medium">{selectedReview.rating}/5</span>
                  </div>
                </div>
              </div>

              <div className="prose max-w-none">
                <p className="text-lg leading-relaxed text-muted-foreground">
                  {selectedReview.fullReview}
                </p>
              </div>

              {/* Detailed Scores */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Detailed Scores</h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(selectedReview.score).map(([category, score]) => (
                      <div key={category} className="text-center">
                        <div className="text-2xl font-bold text-primary mb-1">{score}</div>
                        <div className="text-sm text-muted-foreground capitalize">{category}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Specifications */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Specifications</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {Object.entries(selectedReview.specs).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                        <span className="font-medium">{value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Pros & Cons */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-green-600 mb-4">Pros</h3>
                    <ul className="space-y-2">
                      {selectedReview.pros.map((pro: string, i: number) => (
                        <li key={i} className="flex items-start space-x-2">
                          <span className="text-green-500 mt-1">+</span>
                          <span>{pro}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-red-600 mb-4">Cons</h3>
                    <ul className="space-y-2">
                      {selectedReview.cons.map((con: string, i: number) => (
                        <li key={i} className="flex items-start space-x-2">
                          <span className="text-red-500 mt-1">-</span>
                          <span>{con}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Smartphone Reviews</h1>
                <p className="text-sm text-muted-foreground">Latest phone reviews and guides</p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              {smartphoneReviews.length} Reviews
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="reviews" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reviews">Latest Reviews</TabsTrigger>
            <TabsTrigger value="guides">Buying Guides</TabsTrigger>
            <TabsTrigger value="comparisons">Comparisons</TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-8">
            {/* Filters */}
            <div className="flex flex-col md:flex-row gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search smartphones..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedBrand} onValueChange={setSelectedBrand}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  <SelectItem value="apple">Apple</SelectItem>
                  <SelectItem value="samsung">Samsung</SelectItem>
                  <SelectItem value="google">Google</SelectItem>
                  <SelectItem value="oneplus">OnePlus</SelectItem>
                  <SelectItem value="xiaomi">Xiaomi</SelectItem>
                  <SelectItem value="nothing">Nothing</SelectItem>
                  <SelectItem value="asus">ASUS</SelectItem>
                  <SelectItem value="motorola">Motorola</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="flagship">Flagship</SelectItem>
                  <SelectItem value="mid-range">Mid-Range</SelectItem>
                  <SelectItem value="performance">Performance</SelectItem>
                  <SelectItem value="camera">Camera</SelectItem>
                  <SelectItem value="gaming">Gaming</SelectItem>
                  <SelectItem value="budget">Budget</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Reviews Grid */}
            <div className="grid lg:grid-cols-2 gap-8">
              {filteredReviews.map((review, index) => (
                <Card 
                  key={review.id} 
                  className={`overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1 ${index === 0 ? 'lg:col-span-2' : ''}`}
                  onClick={() => setSelectedReview(review)}
                >
                  <div className={`${index === 0 ? 'aspect-[16/9]' : 'aspect-[4/3]'} relative overflow-hidden`}>
                    <ImageWithFallback 
                      src={review.image}
                      alt={review.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className="bg-black/80 text-white">
                        {review.brand}
                      </Badge>
                      <Badge variant="secondary">
                        {review.category}
                      </Badge>
                      {review.featured && (
                        <Badge className="bg-red-500 text-white">
                          Featured
                        </Badge>
                      )}
                    </div>
                    <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {review.price}
                    </div>
                  </div>
                  <CardContent className={`${index === 0 ? 'p-8' : 'p-6'}`}>
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${
                              i < Math.floor(review.rating) 
                                ? 'fill-yellow-400 text-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium">{review.rating}/5</span>
                    </div>
                    <h3 className={`${index === 0 ? 'text-2xl' : 'text-lg'} font-semibold mb-3 group-hover:text-primary transition-colors`}>
                      {review.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 line-clamp-2">{review.excerpt}</p>
                    
                    {/* Pros & Cons */}
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <h5 className="text-sm font-medium text-green-600 mb-2">Pros</h5>
                        <ul className="text-xs space-y-1">
                          {review.pros.slice(0, 2).map((pro, i) => (
                            <li key={i} className="text-muted-foreground">• {pro}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-red-600 mb-2">Cons</h5>
                        <ul className="text-xs space-y-1">
                          {review.cons.slice(0, 2).map((con, i) => (
                            <li key={i} className="text-muted-foreground">• {con}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{review.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{review.readTime}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">Read Full Review</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guides" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold mb-2">Smartphone Buying Guides</h2>
              <p className="text-muted-foreground">Expert advice to help you choose the perfect phone</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {buyingGuides.map((guide) => {
                const IconComponent = guide.icon;
                return (
                  <Card key={guide.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                    <CardContent className="p-6 text-center">
                      <div className={`${guide.color} text-white rounded-full p-4 w-16 h-16 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <IconComponent className="h-8 w-8" />
                      </div>
                      <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                        {guide.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        {guide.description}
                      </p>
                      <Button variant="outline" size="sm">Read Guide</Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="comparisons">
            <div className="text-center py-16">
              <Smartphone className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-2xl font-semibold mb-2">Phone Comparisons</h2>
              <p className="text-muted-foreground mb-8">Detailed head-to-head comparisons coming soon</p>
              <Button>Request a Comparison</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}