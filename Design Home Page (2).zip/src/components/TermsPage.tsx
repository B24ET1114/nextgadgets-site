import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { ArrowLeft, FileText, Scale, Shield, AlertTriangle } from "lucide-react";

interface TermsPageProps {
  onBack: () => void;
}

export function TermsPage({ onBack }: TermsPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Terms of Service</h1>
                <p className="text-sm text-muted-foreground">Legal terms and conditions</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-4">Terms of Service</h1>
            <p className="text-lg text-muted-foreground">
              Last updated: January 18, 2025
            </p>
          </div>

          {/* Quick Overview */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <Card className="text-center">
              <CardContent className="p-6">
                <FileText className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">User Agreement</h3>
                <p className="text-sm text-muted-foreground">By using our site, you agree to these terms</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <Scale className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Fair Use</h3>
                <p className="text-sm text-muted-foreground">Guidelines for appropriate use of our content</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Content Protection</h3>
                <p className="text-sm text-muted-foreground">Our intellectual property rights</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <AlertTriangle className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Limitations</h3>
                <p className="text-sm text-muted-foreground">Understanding liability and disclaimers</p>
              </CardContent>
            </Card>
          </div>

          {/* Terms Content */}
          <div className="space-y-8">
            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">1. Acceptance of Terms</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    By accessing and using NextGadgets.tech (the "Service"), you accept and agree to be bound 
                    by the terms and provision of this agreement.
                  </p>
                  <p>
                    If you do not agree to abide by the above, please do not use this service. These terms 
                    apply to all visitors, users, and others who access or use the Service.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">2. Use License</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    Permission is granted to temporarily download one copy of the materials on NextGadgets.tech 
                    for personal, non-commercial transitory viewing only.
                  </p>
                  <p>This is the grant of a license, not a transfer of title, and under this license you may not:</p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li>Modify or copy the materials</li>
                    <li>Use the materials for any commercial purpose or for any public display</li>
                    <li>Attempt to reverse engineer any software contained on the website</li>
                    <li>Remove any copyright or other proprietary notations from the materials</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">3. User Content</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    Our Service may allow you to post, link, store, share and otherwise make available certain 
                    information, text, graphics, videos, or other material ("Content").
                  </p>
                  <p>You are responsible for Content that you post to the Service, including its legality, reliability, and appropriateness.</p>
                  <p>By posting Content to the Service, you grant us the right and license to use, modify, publicly perform, publicly display, reproduce, and distribute such Content on and through the Service.</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">4. Privacy Policy</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    Your privacy is important to us. Please review our Privacy Policy, which also governs 
                    your use of the Service, to understand our practices.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">5. Prohibited Uses</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>You may not use our Service:</p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li>For any unlawful purpose or to solicit others to unlawful acts</li>
                    <li>To violate any international, federal, provincial, or state regulations, rules, laws, or local ordinances</li>
                    <li>To infringe upon or violate our intellectual property rights or the intellectual property rights of others</li>
                    <li>To harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate</li>
                    <li>To submit false or misleading information</li>
                    <li>To upload or transmit viruses or any other type of malicious code</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">6. Disclaimer</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    The information on this website is provided on an "as is" basis. To the fullest extent 
                    permitted by law, this Company:
                  </p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li>Excludes all representations and warranties relating to this website and its contents</li>
                    <li>Excludes all liability for damages arising out of or in connection with your use of this website</li>
                  </ul>
                  <p>
                    The materials on NextGadgets.tech are provided for general information only and should not be 
                    relied upon for making purchasing decisions without consulting primary, more accurate, more complete, 
                    or more timely sources of information.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">7. Limitations</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    In no event shall NextGadgets.tech or its suppliers be liable for any damages (including, 
                    without limitation, damages for loss of data or profit, or due to business interruption) 
                    arising out of the use or inability to use the materials on NextGadgets.tech's website.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">8. Accuracy of Materials</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    The materials appearing on NextGadgets.tech could include technical, typographical, or 
                    photographic errors. NextGadgets.tech does not warrant that any of the materials on its 
                    website are accurate, complete, or current.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">9. Modifications</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    NextGadgets.tech may revise these terms of service for its website at any time without notice. 
                    By using this website, you are agreeing to be bound by the then current version of these terms of service.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">10. Contact Information</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    If you have any questions about these Terms of Service, please contact us at:
                  </p>
                  <div className="bg-muted/30 p-4 rounded-lg">
                    <p><strong>Email:</strong> nextgadgets@tutamail.com</p>
                    <p><strong>Address:</strong> NextGadgets.tech, Maharashtra, India</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}