import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { toast } from "sonner@2.0.3";
import { Mail, Bell, Star, CheckCircle, Loader2, Sparkles, Zap, Gift, Users, Shield } from "lucide-react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentFeature, setCurrentFeature] = useState(0);
  const [particles, setParticles] = useState<Array<{id: number, x: number, y: number}>>([]);

  const features = [
    { icon: Star, text: "Exclusive Tech Insights", color: "text-yellow-500" },
    { icon: Zap, text: "Early Access Reviews", color: "text-blue-500" },
    { icon: Gift, text: "Special Offers & Deals", color: "text-green-500" },
    { icon: Users, text: "Community Access", color: "text-purple-500" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Generate floating particles
    const newParticles = Array.from({ length: 6 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100
    }));
    setParticles(newParticles);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsLoading(true);
    
    // Simulate API call with more excitement
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubscribed(true);
    setIsLoading(false);
    setEmail("");
    
    toast.success("🎉 Welcome to NextGadgets!", {
      description: "You'll receive exclusive tech insights every Friday. Check your email for a welcome gift!"
    });
  };
  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Enhanced Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-br from-primary/20 to-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-gradient-to-br from-purple-500/20 to-pink-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-green-500/15 to-yellow-500/10 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>
      
      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map(particle => (
          <div
            key={particle.id}
            className="absolute w-2 h-2 bg-primary/30 rounded-full animate-pulse"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              animationDelay: `${particle.id * 0.5}s`,
              animationDuration: `${3 + particle.id}s`
            }}
          />
        ))}
        <Sparkles className="absolute top-20 left-20 h-6 w-6 text-primary/40 animate-pulse" />
        <Zap className="absolute bottom-24 right-32 h-5 w-5 text-yellow-500/40 animate-pulse" style={{ animationDelay: '1s' }} />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <Card className="glass-futuristic backdrop-blur-strong hover-lift-futuristic transition-all duration-700 relative overflow-hidden border-0">
          {/* Animated Border */}
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-transparent to-primary/20 opacity-0 hover:opacity-100 transition-opacity duration-700"></div>
          
          <CardContent className="p-10 md:p-16 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <Badge variant="secondary" className="mb-8 glass-premium hover-scale interactive animate-fade-in-up border border-primary/20 bg-gradient-to-r from-primary/10 to-primary/5 text-lg px-6 py-2 badge-text-safe">
                <Bell className="h-4 w-4 mr-2 animate-pulse" />
                <span className="text-primary force-primary">
                  Stay Updated
                </span>
              </Badge>
              
              <h2 className="text-4xl md:text-6xl mb-6 animate-fade-in-up text-foreground force-visible" style={{ animationDelay: '0.2s' }}>
                Never Miss a Review
              </h2>
              
              <p className="text-xl text-muted-foreground mb-10 animate-fade-in-up leading-relaxed" style={{ animationDelay: '0.4s' }}>
                Get the latest tech reviews, buying guides, and exclusive insights delivered straight to your inbox. Join over 
                <span className="text-primary font-semibold"> 100,000+ tech enthusiasts.</span>
              </p>

              {/* Dynamic Features Showcase */}
              <div className="mb-8 animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
                <div className="flex justify-center items-center space-x-8">
                  {features.map((feature, index) => {
                    const IconComponent = feature.icon;
                    const isActive = index === currentFeature;
                    return (
                      <div 
                        key={index}
                        className={`flex items-center space-x-2 transition-all duration-500 ${
                          isActive ? 'scale-110 opacity-100' : 'scale-100 opacity-60'
                        }`}
                      >
                        <IconComponent className={`h-5 w-5 ${feature.color} ${isActive ? 'animate-pulse' : ''}`} />
                        <span className={`text-sm font-medium hidden sm:block ${isActive ? 'text-foreground' : 'text-muted-foreground'}`}>
                          {feature.text}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Enhanced Newsletter Form */}
              {!isSubscribed ? (
                <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-6 max-w-xl mx-auto mb-10 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
                  <div className="flex-1 relative group">
                    <Input 
                      type="email" 
                      placeholder="Enter your email address" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="h-14 text-lg glass-futuristic backdrop-blur-glass interactive border-primary/20 focus:border-primary/40 transition-all duration-500 px-6 rounded-xl"
                    />
                    <div className="absolute inset-0 rounded-xl border border-primary/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
                    <Mail className="absolute right-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
                  </div>
                  
                  <Button 
                    type="submit" 
                    size="lg" 
                    disabled={isLoading || !email}
                    className="px-10 h-14 text-lg interactive glass-premium hover-lift-futuristic hover-glow-futuristic group relative overflow-hidden rounded-xl"
                  >
                    <span className="relative z-10 flex items-center space-x-2">
                      {isLoading ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <Sparkles className="h-5 w-5 group-hover:rotate-12 transition-transform duration-300" />
                      )}
                      <span>{isLoading ? "Subscribing..." : "Subscribe Now"}</span>
                    </span>
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    {/* Loading Animation */}
                    {isLoading && (
                      <div className="absolute inset-0 bg-gradient-to-r from-primary/30 via-primary/50 to-primary/30 animate-pulse"></div>
                    )}
                  </Button>
                </form>
              ) : (
                <div className="glass-premium rounded-2xl p-8 max-w-lg mx-auto mb-10 animate-fade-in-up border border-green-500/30 bg-gradient-to-r from-green-500/10 to-emerald-500/5">
                  <div className="flex items-center justify-center space-x-3 mb-4">
                    <CheckCircle className="h-8 w-8 text-green-500 animate-pulse" />
                    <span className="text-2xl font-semibold text-green-600 force-visible">
                      Welcome Aboard! 🎉
                    </span>
                  </div>
                  <p className="text-muted-foreground text-center">
                    You're now part of our exclusive tech community. Check your email for a special welcome gift!
                  </p>
                  
                  {/* Celebration particles */}
                  <div className="absolute inset-0 overflow-hidden pointer-events-none">
                    <div className="absolute top-2 left-2 w-2 h-2 bg-green-500 rounded-full animate-ping"></div>
                    <div className="absolute top-4 right-6 w-1 h-1 bg-yellow-500 rounded-full animate-ping" style={{ animationDelay: '0.3s' }}></div>
                    <div className="absolute bottom-3 left-8 w-1.5 h-1.5 bg-blue-500 rounded-full animate-ping" style={{ animationDelay: '0.6s' }}></div>
                  </div>
                </div>
              )}

              {/* Enhanced Social Proof */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8 animate-fade-in-up" style={{ animationDelay: '0.8s' }}>
                <div className="flex flex-col items-center space-y-2 p-4 glass rounded-xl hover-scale interactive">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-blue-500 animate-pulse" />
                    <span className="text-lg font-semibold text-blue-500 force-visible">100K+</span>
                  </div>
                  <span className="text-sm text-muted-foreground">Subscribers</span>
                </div>
                
                <div className="flex flex-col items-center space-y-2 p-4 glass rounded-xl hover-scale interactive">
                  <div className="flex items-center space-x-2">
                    <Star className="h-5 w-5 text-yellow-500 animate-pulse" />
                    <span className="text-lg font-semibold text-yellow-500 force-visible">4.9/5</span>
                  </div>
                  <span className="text-sm text-muted-foreground">Rating</span>
                </div>
                
                <div className="flex flex-col items-center space-y-2 p-4 glass rounded-xl hover-scale interactive">
                  <div className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-green-500 animate-pulse" />
                    <span className="text-lg font-semibold text-green-500 force-visible">Zero</span>
                  </div>
                  <span className="text-sm text-muted-foreground">Spam</span>
                </div>
              </div>

              <div className="flex flex-col items-center space-y-2 text-center animate-fade-in-up" style={{ animationDelay: '1s' }}>
                <p className="text-sm text-muted-foreground">
                  Trusted by tech enthusiasts worldwide • Weekly insights • Exclusive content
                </p>
                <p className="text-xs text-muted-foreground opacity-70">
                  Unsubscribe at any time. We respect your privacy and will never share your email.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}