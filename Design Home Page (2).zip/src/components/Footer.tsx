import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import { 
  Smartphone, 
  Mail,
  MapPin
} from "lucide-react";

const footerLinks = {
  Reviews: [
    "Smartphones",
    "Laptops", 
    "Headphones",
    "Smartwatches",
    "Cameras"
  ],
  Resources: [
    "Buying Guides",
    "Comparisons",
    "News",
    "Best Lists",
    "Deals"
  ],
  Company: [
    "About Us",
    "Our Team",
    "Editorial Policy",
    "Contact",
    "Careers"
  ],
  Support: [
    "Help Center",
    "Privacy Policy",
    "Terms of Service",
    "Cookie Policy",
    "Advertise"
  ]
};



interface FooterProps {
  onNavigate?: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-muted/30 border-t glass backdrop-blur-glass relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse-soft"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-secondary/5 rounded-full blur-3xl animate-pulse-soft" style={{ animationDelay: '2s' }}></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
            {/* Brand Section */}
            <div className="lg:col-span-2 animate-fade-in-left">
              <div className="flex items-center space-x-2 mb-4">
                <div className="bg-primary text-primary-foreground rounded-lg p-2 animate-glow hover-scale interactive">
                  <Smartphone className="h-6 w-6" />
                </div>
                <span className="font-bold text-xl hover-glow interactive">NextGadgets.tech</span>
              </div>
              <p className="text-muted-foreground mb-6 max-w-sm">
                Your trusted source for in-depth tech reviews, buying guides, and the latest gadget news. Making technology accessible for everyone.
              </p>

            </div>

            {/* Links Sections */}
            {Object.entries(footerLinks).map(([category, links], index) => (
              <div key={category} className="animate-fade-in-up stagger-child" style={{ animationDelay: `${0.2 + index * 0.1}s` }}>
                <h4 className="font-semibold mb-4">{category}</h4>
                <ul className="space-y-3">
                  {links.map((link) => (
                    <li key={link}>
                      <button 
                        onClick={() => {
                          const linkMap: Record<string, string> = {
                            "Smartphones": "smartphones",
                            "Laptops": "laptops",
                            "Headphones": "audio",
                            "Smartwatches": "wearables", 
                            "Cameras": "cameras",
                            "Buying Guides": "buyingguides",
                            "News": "news",
                            "About Us": "about",
                            "Our Team": "about",
                            "Contact": "contact",
                            "Privacy Policy": "privacy",
                            "Terms of Service": "terms"
                          };
                          if (linkMap[link]) {
                            onNavigate?.(linkMap[link]);
                          }
                        }}
                        className="text-muted-foreground hover:text-primary transition-all duration-300 text-sm text-left interactive hover-glow"
                      >
                        {link}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Bottom Section */}
        <div className="py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 animate-fade-in-up" style={{ animationDelay: '0.8s' }}>
            <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-6 text-sm text-muted-foreground">
              <p>© 2025 NextGadgets.tech. All rights reserved.</p>
              <div className="flex items-center space-x-1">
                <MapPin className="h-4 w-4" />
                <span>Maharashtra, India</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-xs glass backdrop-blur-glass hover-scale interactive">
                <Mail className="h-3 w-3 mr-1" />
                nextgadgets@tutamail.com
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}