import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  Search, 
  Clock, 
  User, 
  ArrowLeft,
  TrendingUp,
  Calendar,
  Eye,
  Share
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const newsArticles = [
  {
    id: 1,
    title: "Apple Announces Revolutionary M4 Chip with AI Acceleration",
    category: "Apple",
    excerpt: "Apple's latest M4 chip promises 50% better AI performance and enhanced neural engine capabilities for next-generation Macs and iPads...",
    image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBcHBsZSUyME00JTIwY2hpcCUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzU4MjE5NTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Sarah Johnson",
    publishDate: "2025-01-18",
    readTime: "5 min read",
    views: "15.2K",
    featured: true
  },
  {
    id: 2,
    title: "Samsung Galaxy S25 Ultra Leaked: What to Expect",
    category: "Samsung",
    excerpt: "New leaks reveal Samsung's flagship will feature improved cameras, faster charging, and a redesigned S Pen with enhanced functionality...",
    image: "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTYW1zdW5nJTIwR2FsYXh5JTIwUzI1fGVufDF8fHx8MTc1ODIxOTUwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Mike Rodriguez",
    publishDate: "2025-01-17",
    readTime: "4 min read",
    views: "12.8K"
  },
  {
    id: 3,
    title: "CES 2025: Top Tech Trends and Breakthrough Innovations",
    category: "Industry",
    excerpt: "From AI-powered smart homes to next-gen gaming hardware, CES 2025 showcased the future of consumer technology...",
    image: "https://images.unsplash.com/photo-1540979388789-6cee28a1cdc9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDRVMlMjAyMDI1JTIwdGVjaCUyMGV4aGliaXRpb258ZW58MXx8fHwxNzU4MjE5NTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Tech Reviewer",
    publishDate: "2025-01-16",
    readTime: "8 min read",
    views: "9.7K"
  },
  {
    id: 4,
    title: "Google Pixel 9a Rumors: Budget Phone Gets Premium Features",
    category: "Google",
    excerpt: "Leaked specifications suggest Google's affordable Pixel will include advanced AI photography features and flagship-level performance...",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxHb29nbGUlMjBQaXhlbCUyMDlhfGVufDF8fHx8MTc1ODIxOTUwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "David Kim",
    publishDate: "2025-01-15",
    readTime: "3 min read",
    views: "8.4K"
  },
  {
    id: 5,
    title: "Nintendo Switch 2: Release Date and Specifications Revealed",
    category: "Gaming",
    excerpt: "Nintendo officially announces the Switch 2 with 4K docked gaming, backwards compatibility, and enhanced performance...",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhOaW50ZW5kbyUyMFN3aXRjaCUyMDJ8ZW58MXx8fHwxNzU4MjE5NTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Tech Reviewer",
    publishDate: "2025-01-14",
    readTime: "6 min read",
    views: "18.9K"
  },
  {
    id: 6,
    title: "Tesla Phone: Elon Musk's Smartphone Plans Confirmed",
    category: "Tesla",
    excerpt: "Tesla enters the smartphone market with Starlink integration, solar charging, and unique Neuralink compatibility features...",
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUZXNsYSUyMHBob25lJTIwY29uY2VwdHxlbnwxfHx8fDE3NTgyMTk1MDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Sarah Johnson",
    publishDate: "2025-01-13",
    readTime: "7 min read",
    views: "22.1K"
  }
];

const categories = [
  "All",
  "Apple",
  "Samsung", 
  "Google",
  "Gaming",
  "Industry",
  "Tesla",
  "AI",
  "5G"
];

interface NewsPageProps {
  onBack: () => void;
}

export function NewsPage({ onBack }: NewsPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredArticles = newsArticles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const featuredArticle = filteredArticles.find(article => article.featured) || filteredArticles[0];
  const regularArticles = filteredArticles.filter(article => !article.featured);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Tech News</h1>
                <p className="text-sm text-muted-foreground">Latest technology news and industry updates</p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              Breaking News
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search news articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Featured Article */}
        {featuredArticle && (
          <Card className="mb-8 overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer">
            <div className="grid lg:grid-cols-2 gap-0">
              <div className="aspect-[16/10] relative overflow-hidden">
                <ImageWithFallback 
                  src={featuredArticle.image}
                  alt={featuredArticle.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-red-500 text-white">
                    Breaking
                  </Badge>
                </div>
              </div>
              <CardContent className="p-8">
                <Badge variant="outline" className="mb-3">
                  {featuredArticle.category}
                </Badge>
                <h2 className="text-2xl font-semibold mb-3 group-hover:text-primary transition-colors">
                  {featuredArticle.title}
                </h2>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {featuredArticle.excerpt}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <User className="h-4 w-4" />
                      <span>{featuredArticle.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(featuredArticle.publishDate).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{featuredArticle.readTime}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Eye className="h-4 w-4" />
                      <span>{featuredArticle.views}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Share className="h-4 w-4 mr-2" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </div>
          </Card>
        )}

        {/* Regular Articles Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regularArticles.map((article) => (
            <Card key={article.id} className="overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
              <div className="aspect-[16/10] relative overflow-hidden">
                <ImageWithFallback 
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <Badge variant="secondary">
                    {article.category}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {article.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                  {article.excerpt}
                </p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-1">
                      <User className="h-3 w-3" />
                      <span>{article.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(article.publishDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-1">
                      <Clock className="h-3 w-3" />
                      <span>{article.readTime}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Eye className="h-3 w-3" />
                      <span>{article.views}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline">
            Load More Articles
          </Button>
        </div>
      </div>
    </div>
  );
}