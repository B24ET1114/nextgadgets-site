import { memo, useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Star, TrendingUp, Play, Zap, Users, Shield, Award, ChevronRight, Sparkles } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HeroProps {
  onNavigate?: (page: string) => void;
}

export const Hero = memo(function Hero({
  onNavigate,
}: HeroProps) {
  const [currentStatsIndex, setCurrentStatsIndex] = useState(0);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const dynamicStats = [
    { icon: Star, text: "1000+ Reviews", color: "text-yellow-500" },
    { icon: Users, text: "50M+ Readers", color: "text-blue-500" },
    { icon: Shield, text: "Expert Tested", color: "text-green-500" },
    { icon: Award, text: "Industry Leader", color: "text-purple-500" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStatsIndex((prev) => (prev + 1) % dynamicStats.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      {/* Dynamic Background with Parallax Effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-muted/10 to-background"></div>
      
      {/* Animated Grid Background */}
      <div className="absolute inset-0 opacity-30">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              radial-gradient(circle at ${mousePosition.x * 0.1}px ${mousePosition.y * 0.1}px, rgba(3,2,19,0.1) 1px, transparent 1px),
              linear-gradient(rgba(3,2,19,0.05) 1px, transparent 1px),
              linear-gradient(90deg, rgba(3,2,19,0.05) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px, 40px 40px, 40px 40px'
          }}
        ></div>
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-gradient-to-br from-green-500/20 to-green-400/10 rounded-full blur-lg animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-32 left-1/4 w-24 h-24 bg-gradient-to-br from-blue-500/20 to-blue-400/10 rounded-full blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        <Sparkles className="absolute top-32 right-1/3 h-8 w-8 text-primary/30 animate-pulse" style={{ animationDelay: '0.5s' }} />
        <Zap className="absolute bottom-40 right-10 h-6 w-6 text-yellow-500/40 animate-pulse" style={{ animationDelay: '1.5s' }} />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Enhanced Content */}
          <div className="space-y-8">
            <Badge variant="secondary" className="w-fit glass animate-fade-in-up border border-primary/20 bg-gradient-to-r from-primary/10 to-primary/5 hover-scale interactive">
              <TrendingUp className="h-4 w-4 mr-2 animate-pulse" />
              <span className="text-primary force-primary">
                Latest Tech Reviews & Guides
              </span>
            </Badge>
            
            <h1 className="text-5xl md:text-7xl animate-fade-in-up leading-tight force-visible" style={{ animationDelay: '0.2s' }}>
              <span className="text-foreground">
                Your Ultimate
              </span>
              <span className="block text-primary hover:scale-105 transition-transform duration-300 cursor-default">
                Tech Review
              </span>
              <span className="text-foreground">
                Destination
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl leading-relaxed animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
              Discover comprehensive reviews, detailed comparisons, and expert buying guides for the 
              <span className="text-primary font-medium"> latest gadgets </span>
              and technology products.
            </p>

            {/* Enhanced Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
              <Button
                size="lg"
                className="glass-premium hover-lift-futuristic hover-glow-futuristic interactive group relative overflow-hidden px-8 py-4 text-lg"
                onClick={() => onNavigate?.("smartphones")}
              >
                <span className="relative z-10 flex items-center space-x-2">
                  <span>Browse Reviews</span>
                  <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
              
              <Button
                size="lg"
                variant="outline"
                className="glass hover-lift interactive group relative overflow-hidden px-8 py-4 text-lg border-primary/20 hover:border-primary/40"
                onClick={() => onNavigate?.("news")}
              >
                <span className="relative z-10 flex items-center space-x-2">
                  <Play className="h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                  <span>Latest News</span>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
            </div>

            {/* Dynamic Stats Display */}
            <div className="flex items-center space-x-8 animate-fade-in-up" style={{ animationDelay: '0.8s' }}>
              {dynamicStats.map((stat, index) => {
                const IconComponent = stat.icon;
                const isActive = index === currentStatsIndex;
                return (
                  <div 
                    key={index}
                    className={`flex items-center space-x-2 transition-all duration-500 ${
                      isActive ? 'scale-110 opacity-100' : 'scale-100 opacity-60'
                    }`}
                  >
                    <IconComponent className={`h-5 w-5 ${stat.color} ${isActive ? 'animate-pulse' : ''}`} />
                    <span className={`text-sm font-medium ${isActive ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {stat.text}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Enhanced Featured Image */}
          <div className="relative animate-fade-in-up" style={{ animationDelay: '1s' }}>
            {/* Main Image Container */}
            <div className="relative group">
              <div className="aspect-[4/3] rounded-3xl overflow-hidden glass-premium shadow-2xl relative">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1585789574224-8cbf3247e581?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwd29ya3NwYWNlJTIwZ2FkZ2V0c3xlbnwxfHx8fDE3NTgyMTgwNzR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Modern tech workspace with various gadgets"
                  className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:brightness-110"
                />
                
                {/* Holographic Overlay */}
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 via-transparent to-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                {/* Scan Line Effect */}
                <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-primary to-transparent translate-y-0 group-hover:translate-y-full transition-transform duration-2000 ease-out"></div>
              </div>
              
              {/* Glow Effect */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-primary/30 to-primary/10 blur-2xl opacity-0 group-hover:opacity-50 transition-opacity duration-700 scale-110"></div>
            </div>

            {/* Enhanced Review Card */}
            <div className="absolute -bottom-6 -left-6 glass-premium rounded-2xl p-6 shadow-2xl border border-primary/20 hover-lift interactive group animate-fade-in-up" style={{ animationDelay: '1.2s' }}>
              <div className="flex items-center space-x-3 mb-3">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-5 w-5 fill-yellow-400 text-yellow-400 group-hover:animate-pulse"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    />
                  ))}
                </div>
                <span className="font-semibold text-lg text-foreground force-visible">
                  4.9/5
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                Latest iPhone 15 Pro Review
              </p>
              <Badge variant="outline" className="text-xs border-green-500/30 bg-green-500/10 text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                Just Published
              </Badge>
              
              {/* Floating Particles */}
              <div className="absolute -top-2 -right-2 w-3 h-3 bg-primary/60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-ping"></div>
              <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-yellow-500/60 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-ping" style={{ animationDelay: '0.3s' }}></div>
            </div>

            {/* Floating Tech Icons */}
            <div className="absolute top-4 right-4 glass rounded-full p-3 opacity-0 group-hover:opacity-100 transition-all duration-500 hover-scale">
              <Zap className="h-6 w-6 text-primary animate-pulse" />
            </div>
            
            <div className="absolute bottom-20 right-8 glass rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all duration-700 hover-scale" style={{ animationDelay: '0.2s' }}>
              <Award className="h-5 w-5 text-yellow-500 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});