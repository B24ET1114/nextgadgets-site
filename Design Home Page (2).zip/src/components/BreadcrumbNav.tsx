import { ChevronRight, Home } from "lucide-react";
import { Button } from "./ui/button";

interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
  current?: boolean;
}

interface BreadcrumbNavProps {
  items: BreadcrumbItem[];
  onNavigate?: (page: string) => void;
}

export function BreadcrumbNav({ items, onNavigate }: BreadcrumbNavProps) {
  return (
    <nav className="flex items-center space-x-1 text-sm text-muted-foreground mb-6">
      <Button 
        variant="ghost" 
        size="sm" 
        onClick={() => onNavigate?.("home")}
        className="h-auto p-1 text-muted-foreground hover:text-foreground"
      >
        <Home className="h-4 w-4" />
      </Button>
      
      {items.map((item, index) => (
        <div key={index} className="flex items-center space-x-1">
          <ChevronRight className="h-4 w-4" />
          {item.current ? (
            <span className="font-medium text-foreground">{item.label}</span>
          ) : (
            <Button 
              variant="ghost" 
              size="sm"
              onClick={item.onClick}
              className="h-auto p-1 text-muted-foreground hover:text-foreground"
            >
              {item.label}
            </Button>
          )}
        </div>
      ))}
    </nav>
  );
}