import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Cookie, X, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CookieConsentProps {
  onAccept?: (type: 'essential' | 'all') => void;
}

export function CookieConsent({ onAccept }: CookieConsentProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    // Check if user has already made a choice
    const cookieConsent = localStorage.getItem('cookie-consent');
    if (!cookieConsent) {
      // Show banner after a brief delay for better UX
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = (type: 'essential' | 'all') => {
    localStorage.setItem('cookie-consent', type);
    setIsVisible(false);
    onAccept?.(type);
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-md z-[9999]"
      >
        <Card className="glass-card border-2 backdrop-blur-strong shadow-2xl">
          <div className="p-6">
            <div className="flex items-start gap-3 mb-4">
              <div className="flex-shrink-0">
                <Cookie className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold mb-2">Cookie Preferences</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  We use cookies to enhance your browsing experience, provide personalized content, and analyze our traffic. 
                  Choose your preferences below.
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleClose}
                className="flex-shrink-0 h-8 w-8 hover-scale interactive"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {!showSettings ? (
              <div className="flex flex-col sm:flex-row gap-2">
                <Button
                  variant="outline"
                  onClick={() => handleAccept('essential')}
                  className="flex-1 interactive hover-lift glass-card"
                >
                  Essential Only
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowSettings(true)}
                  className="interactive hover-scale"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
                <Button
                  onClick={() => handleAccept('all')}
                  className="flex-1 interactive hover-lift bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                >
                  Accept All
                </Button>
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div>
                      <h4 className="font-medium">Essential Cookies</h4>
                      <p className="text-xs text-muted-foreground">Required for basic site functionality</p>
                    </div>
                    <div className="text-xs font-medium text-green-600 dark:text-green-400">
                      Always Active
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                    <div>
                      <h4 className="font-medium">Analytics Cookies</h4>
                      <p className="text-xs text-muted-foreground">Help us understand how you use our site</p>
                    </div>
                    <div className="text-xs font-medium text-blue-600 dark:text-blue-400">
                      Optional
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                    <div>
                      <h4 className="font-medium">Marketing Cookies</h4>
                      <p className="text-xs text-muted-foreground">Used to show relevant ads and content</p>
                    </div>
                    <div className="text-xs font-medium text-blue-600 dark:text-blue-400">
                      Optional
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                  <Button
                    variant="outline"
                    onClick={() => setShowSettings(false)}
                    className="interactive hover-scale"
                  >
                    Back
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleAccept('essential')}
                    className="flex-1 interactive hover-lift"
                  >
                    Essential Only
                  </Button>
                  <Button
                    onClick={() => handleAccept('all')}
                    className="flex-1 interactive hover-lift bg-gradient-to-r from-primary to-primary/80"
                  >
                    Accept All
                  </Button>
                </div>
              </motion.div>
            )}
          </div>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}