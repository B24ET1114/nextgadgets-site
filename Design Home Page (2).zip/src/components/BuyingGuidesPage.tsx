import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Search, 
  Clock, 
  User, 
  ArrowLeft,
  TrendingUp,
  Smartphone,
  Laptop,
  Headphones,
  Watch,
  Camera,
  Gamepad2,
  Tablet,
  Home,
  DollarSign,
  Award,
  Star
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const buyingGuides = [
  {
    id: 1,
    title: "Best Smartphones of 2025: Complete Buyer's Guide",
    category: "Smartphones",
    excerpt: "Our comprehensive guide to choosing the perfect smartphone, from budget options to flagship powerhouses. Compare features, performance, and value.",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHBob25lJTIwYnV5aW5nJTIwZ3VpZGV8ZW58MXx8fHwxNzU4MjE5NTM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Smartphone,
    author: "Sarah Johnson",
    readTime: "15 min read",
    difficulty: "Beginner",
    rating: 4.9,
    views: "45.2K",
    featured: true
  },
  {
    id: 2,
    title: "Gaming Laptop Buying Guide: Performance vs Portability",
    category: "Laptops",
    excerpt: "Everything you need to know about choosing a gaming laptop in 2025. GPU comparisons, cooling solutions, and the best value options.",
    image: "https://images.unsplash.com/photo-1603302576837-37561b2e2302?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBsYXB0b3AlMjBidXlpbmd8ZW58MXx8fHwxNzU4MjE5NTM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Laptop,
    author: "Tech Reviewer",
    readTime: "12 min read",
    difficulty: "Intermediate",
    rating: 4.8,
    views: "32.1K"
  },
  {
    id: 3,
    title: "Wireless Headphones: ANC, Sound Quality & Battery Life",
    category: "Audio",
    excerpt: "The ultimate guide to wireless headphones. Compare noise cancellation, sound signatures, and find the perfect pair for your needs.",
    image: "https://images.unsplash.com/photo-1632200004922-bc18602c79fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aXJlbGVzcyUyMGhlYWRwaG9uZXMlMjBndWlkZXxlbnwxfHx8fDE3NTgyMTk1Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Headphones,
    author: "Mike Rodriguez",
    readTime: "10 min read",
    difficulty: "Beginner",
    rating: 4.7,
    views: "28.5K"
  },
  {
    id: 4,
    title: "Smart Home Starter Guide: Building Your Connected Home",
    category: "Smart Home",
    excerpt: "Start your smart home journey right. Essential devices, compatibility considerations, and setup tips for beginners.",
    image: "https://images.unsplash.com/photo-1519558260268-cde7e03a0152?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydCUyMGhvbWUlMjBndWlkZXxlbnwxfHx8fDE3NTgyMTk1Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Home,
    author: "David Kim",
    readTime: "14 min read",
    difficulty: "Beginner",
    rating: 4.6,
    views: "19.8K"
  },
  {
    id: 5,
    title: "Smartwatch Buying Guide: Fitness vs Features",
    category: "Wearables",
    excerpt: "Choose between fitness tracking and smart features. Compare Apple Watch, Galaxy Watch, and fitness-focused alternatives.",
    image: "https://images.unsplash.com/photo-1598516802414-50a01bee818d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHdhdGNoJTIwZ3VpZGV8ZW58MXx8fHwxNzU4MjE5NTM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Watch,
    author: "Sarah Johnson",
    readTime: "9 min read",
    difficulty: "Beginner",
    rating: 4.5,
    views: "15.3K"
  },
  {
    id: 6,
    title: "Camera Buying Guide: DSLR vs Mirrorless in 2025",
    category: "Cameras",
    excerpt: "The complete guide to choosing your next camera. Compare sensor sizes, lens ecosystems, and find the best camera for your photography needs.",
    image: "https://images.unsplash.com/photo-1580050815120-3862a5833e0e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1lcmElMjBidXlpbmclMjBndWlkZXxlbnwxfHx8fDE3NTgyMTk1Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Camera,
    author: "Tech Reviewer",
    readTime: "16 min read",
    difficulty: "Intermediate",
    rating: 4.8,
    views: "22.7K"
  },
  {
    id: 7,
    title: "Budget Gaming Setup: Maximum Performance Under $1000",
    category: "Gaming",
    excerpt: "Build an amazing gaming setup without breaking the bank. Console vs PC, essential accessories, and money-saving tips.",
    image: "https://images.unsplash.com/photo-1655976796204-308e6f3deaa8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidWRnZXQlMjBnYW1pbmclMjBzZXR1cHxlbnwxfHx8fDE3NTgyMTk1Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Gamepad2,
    author: "Mike Rodriguez",
    readTime: "13 min read",
    difficulty: "Intermediate",
    rating: 4.7,
    views: "35.9K"
  },
  {
    id: 8,
    title: "iPad vs Android Tablets: Which Should You Choose?",
    category: "Tablets",
    excerpt: "The ultimate tablet comparison guide. App ecosystems, productivity features, and value propositions compared.",
    image: "https://images.unsplash.com/photo-1672239069328-dd1535c0d78a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZXQlMjBjb21wYXJpc29uJTIwZ3VpZGV8ZW58MXx8fHwxNzU4MjE5NTM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    icon: Tablet,
    author: "David Kim",
    readTime: "11 min read",
    difficulty: "Beginner",
    rating: 4.6,
    views: "18.4K"
  }
];

const categories = [
  { name: "All", icon: Award },
  { name: "Smartphones", icon: Smartphone },
  { name: "Laptops", icon: Laptop },
  { name: "Audio", icon: Headphones },
  { name: "Gaming", icon: Gamepad2 },
  { name: "Cameras", icon: Camera },
  { name: "Wearables", icon: Watch },
  { name: "Tablets", icon: Tablet },
  { name: "Smart Home", icon: Home }
];

interface BuyingGuidesPageProps {
  onBack: () => void;
}

export function BuyingGuidesPage({ onBack }: BuyingGuidesPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredGuides = buyingGuides.filter(guide => {
    const matchesSearch = guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         guide.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || guide.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const featuredGuide = filteredGuides.find(guide => guide.featured) || filteredGuides[0];
  const regularGuides = filteredGuides.filter(guide => !guide.featured);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Buying Guides</h1>
                <p className="text-sm text-muted-foreground">Expert advice to make the right tech choices</p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              {buyingGuides.length} Guides
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search buying guides..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-4 mb-12">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <Card 
                key={category.name}
                className={`cursor-pointer transition-all duration-300 hover:shadow-md ${
                  selectedCategory === category.name ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedCategory(category.name)}
              >
                <CardContent className="p-4 text-center">
                  <IconComponent className={`h-6 w-6 mx-auto mb-2 ${
                    selectedCategory === category.name ? 'text-primary' : 'text-muted-foreground'
                  }`} />
                  <p className={`text-xs font-medium ${
                    selectedCategory === category.name ? 'text-primary' : 'text-muted-foreground'
                  }`}>
                    {category.name}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Featured Guide */}
        {featuredGuide && (
          <Card className="mb-12 overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer">
            <div className="grid lg:grid-cols-2 gap-0">
              <div className="aspect-[16/10] relative overflow-hidden">
                <ImageWithFallback 
                  src={featuredGuide.image}
                  alt={featuredGuide.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4 flex gap-2">
                  <Badge className="bg-green-500 text-white">
                    Featured Guide
                  </Badge>
                  <Badge variant="secondary">
                    {featuredGuide.category}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-4 w-4 ${
                          i < Math.floor(featuredGuide.rating) 
                            ? 'fill-yellow-400 text-yellow-400' 
                            : 'text-gray-300'
                        }`} 
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium">{featuredGuide.rating}/5</span>
                  <Badge variant="outline">{featuredGuide.difficulty}</Badge>
                </div>
                <h2 className="text-2xl font-semibold mb-3 group-hover:text-primary transition-colors">
                  {featuredGuide.title}
                </h2>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {featuredGuide.excerpt}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <User className="h-4 w-4" />
                      <span>{featuredGuide.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{featuredGuide.readTime}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <TrendingUp className="h-4 w-4" />
                      <span>{featuredGuide.views} views</span>
                    </div>
                  </div>
                  <Button>Read Guide</Button>
                </div>
              </CardContent>
            </div>
          </Card>
        )}

        {/* Regular Guides Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regularGuides.map((guide) => {
            const IconComponent = guide.icon;
            return (
              <Card key={guide.id} className="overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                <div className="aspect-[16/10] relative overflow-hidden">
                  <ImageWithFallback 
                    src={guide.image}
                    alt={guide.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <Badge variant="secondary">
                      {guide.category}
                    </Badge>
                    <Badge variant="outline" className="bg-white/90">
                      {guide.difficulty}
                    </Badge>
                  </div>
                  <div className="absolute bottom-4 right-4">
                    <div className="bg-primary text-primary-foreground rounded-full p-2">
                      <IconComponent className="h-4 w-4" />
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-3 w-3 ${
                            i < Math.floor(guide.rating) 
                              ? 'fill-yellow-400 text-yellow-400' 
                              : 'text-gray-300'
                          }`} 
                        />
                      ))}
                    </div>
                    <span className="text-xs font-medium">{guide.rating}/5</span>
                  </div>
                  <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                    {guide.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                    {guide.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-1">
                        <User className="h-3 w-3" />
                        <span>{guide.author}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>{guide.readTime}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <TrendingUp className="h-3 w-3" />
                      <span>{guide.views}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline">
            Load More Guides
          </Button>
        </div>
      </div>
    </div>
  );
}