import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";
import { Switch } from "./ui/switch";
import { Badge } from "./ui/badge";
import { Search, Menu, Smartphone, Moon, Sun, Sparkles, Command } from "lucide-react";

interface HeaderProps {
  onNavigate?: (page: string) => void;
  onSearch?: (query: string) => void;
}

export function Header({ onNavigate, onSearch }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [headerScrolled, setHeaderScrolled] = useState(false);
  const [searchSuggestions] = useState([
    "iPhone 15 Pro review", "MacBook Air M3", "Sony WH-1000XM5", "Steam Deck review"
  ]);

  useEffect(() => {
    const handleScroll = () => {
      setHeaderScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch?.(searchQuery.trim());
      setSearchQuery("");
      setIsSearchFocused(false);
    }
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const navItems = [
    { name: "Smartphones", key: "smartphones" },
    { name: "Laptops", key: "laptops" },
    { name: "Audio", key: "audio" },
    { name: "Gaming", key: "gaming" },
    { name: "News", key: "news" },
    { name: "Guides", key: "buyingguides" },
    { name: "About", key: "about" }
  ];
  return (
    <header className={`bg-background/90 backdrop-blur-strong sticky top-0 z-50 transition-all duration-500 ${headerScrolled ? 'bg-background/95 shadow-lg' : ''}`}>
      {/* Clean Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/3 via-transparent to-primary/3 opacity-0 hover:opacity-100 transition-opacity duration-700"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex h-16 items-center justify-between">
          {/* Enhanced Logo */}
          <div className="flex items-center space-x-3 animate-fade-in-left group cursor-pointer" onClick={() => onNavigate?.('home')}>
            <div className="relative">
              <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-3 hover-scale interactive shadow-xl group-hover:shadow-2xl transition-all duration-500 group-hover:rotate-3">
                <Smartphone className="h-7 w-7 group-hover:scale-110 transition-transform duration-300" />
                {/* Pulsing glow effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary to-primary/80 rounded-2xl blur-xl opacity-0 group-hover:opacity-30 transition-opacity duration-500 scale-150"></div>
              </div>
              {/* Floating sparkles */}
              <Sparkles className="absolute -top-1 -right-1 h-4 w-4 text-primary animate-pulse opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-foreground font-bold text-xl group-hover:scale-105 transition-transform duration-300 force-visible">
                NextGadgets.tech
              </span>
              <span className="text-xs text-muted-foreground hidden sm:block group-hover:text-primary/70 transition-colors duration-300">
                Expert Tech Reviews
              </span>
            </div>
          </div>

          {/* Futuristic Navigation */}
          <nav className="hidden md:flex items-center space-x-2 animate-fade-in-up">
            {navItems.map((item, index) => (
              <button 
                key={item.key}
                onClick={() => onNavigate?.(item.key)} 
                className="relative px-4 py-2 rounded-xl hover:text-primary transition-all duration-500 interactive group overflow-hidden"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <span className="relative z-10 font-medium group-hover:text-primary transition-all duration-300 force-visible">
                  {item.name}
                </span>
                
                {/* Holographic background */}
                <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-primary/20 to-primary/10 rounded-xl opacity-0 group-hover:opacity-100 transition-all duration-500 transform scale-95 group-hover:scale-100"></div>
                
                {/* Animated border */}
                <div className="absolute inset-0 rounded-xl border border-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Subtle highlight effect */}
                <div className="absolute inset-x-0 bottom-0 h-[2px] bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                
                {/* Glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/30 to-primary/0 rounded-xl blur-xl opacity-0 group-hover:opacity-50 transition-all duration-500 scale-150"></div>
              </button>
            ))}
          </nav>

          {/* Enhanced Search and Actions */}
          <div className="flex items-center space-x-4 animate-fade-in-right">
            {/* Advanced Desktop Search */}
            <form onSubmit={handleSearch} className="hidden sm:flex items-center space-x-2">
              <div className="relative group">
                <div className={`relative overflow-hidden rounded-xl border transition-all duration-500 ${isSearchFocused ? 'border-primary/50 shadow-lg shadow-primary/20' : 'border-border/50'}`}>
                  <Input 
                    type="search" 
                    placeholder="Search reviews, guides..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onFocus={() => setIsSearchFocused(true)}
                    onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                    className="w-80 pl-12 pr-20 py-3 bg-background/50 backdrop-blur-md border-0 focus:ring-0 focus:outline-none transition-all duration-300"
                  />
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
                  
                  {/* Keyboard shortcut hint */}
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-1 text-xs text-muted-foreground">
                    <Command className="h-3 w-3" />
                    <span>K</span>
                  </div>
                  
                  {/* Animated border */}
                  <div className="absolute inset-0 rounded-xl border border-primary/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                
                {/* Search Suggestions Dropdown */}
                {isSearchFocused && searchQuery.length === 0 && (
                  <div className="absolute top-full left-0 right-0 mt-2 glass-card rounded-xl border border-border/50 shadow-2xl z-50 animate-fade-in-up">
                    <div className="p-4">
                      <div className="flex items-center space-x-2 mb-3">
                        <Sparkles className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">Popular Searches</span>
                      </div>
                      <div className="space-y-2">
                        {searchSuggestions.map((suggestion, index) => (
                          <button
                            key={index}
                            onClick={() => {
                              setSearchQuery(suggestion);
                              onSearch?.(suggestion);
                              setIsSearchFocused(false);
                            }}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-primary/10 text-sm transition-colors duration-200 group"
                          >
                            <div className="flex items-center space-x-2">
                              <Search className="h-3 w-3 text-muted-foreground group-hover:text-primary transition-colors" />
                              <span>{suggestion}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </form>

            {/* Enhanced Dark Mode Toggle */}
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleDarkMode}
              className="hidden sm:flex interactive hover-scale p-3 rounded-xl glass hover:glass-premium transition-all duration-500 group relative overflow-hidden"
            >
              <div className="relative z-10">
                {isDarkMode ? (
                  <Sun className="h-5 w-5 text-yellow-500 group-hover:rotate-90 transition-transform duration-500" />
                ) : (
                  <Moon className="h-5 w-5 text-blue-500 group-hover:-rotate-12 transition-transform duration-500" />
                )}
              </div>
              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/20 to-blue-500/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>
            </Button>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button size="icon" variant="ghost" className="md:hidden">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col space-y-6 mt-6">
                  {/* Mobile Search */}
                  <form onSubmit={handleSearch} className="flex items-center space-x-2">
                    <Input 
                      type="search" 
                      placeholder="Search reviews..." 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1"
                    />
                    <Button type="submit" size="icon" variant="ghost">
                      <Search className="h-4 w-4" />
                    </Button>
                  </form>

                  {/* Mobile Navigation */}
                  <nav className="flex flex-col space-y-4">
                    {navItems.map((item) => (
                      <button
                        key={item.key}
                        onClick={() => onNavigate?.(item.key)}
                        className="text-left py-2 px-4 rounded-md hover:bg-muted transition-colors"
                      >
                        {item.name}
                      </button>
                    ))}
                  </nav>

                  {/* Mobile Dark Mode Toggle */}
                  <div className="flex items-center justify-between py-2 px-4">
                    <span className="text-sm">Dark Mode</span>
                    <div className="flex items-center space-x-2">
                      <Sun className="h-4 w-4" />
                      <Switch 
                        checked={isDarkMode}
                        onCheckedChange={toggleDarkMode}
                      />
                      <Moon className="h-4 w-4" />
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}