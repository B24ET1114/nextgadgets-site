import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  Search, 
  Star, 
  Clock, 
  User, 
  ArrowLeft,
  Filter,
  X
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

// Combined search results from all categories
const searchResults = [
  {
    id: 1,
    type: "review",
    title: "iPhone 15 Pro Max Review: The Camera King",
    category: "Smartphones",
    excerpt: "Apple's flagship delivers exceptional camera performance and titanium build quality that sets new standards...",
    image: "https://images.unsplash.com/photo-1743677221330-9886caa74fcc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpUGhvbmUlMjAxNSUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzU4MjE4ODQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Alex Chen",
    rating: 4.8,
    readTime: "12 min read",
    price: "$1,199"
  },
  {
    id: 2,
    type: "guide",
    title: "Best Smartphones of 2025: Complete Buyer's Guide",
    category: "Buying Guides",
    excerpt: "Our comprehensive guide to choosing the perfect smartphone, from budget options to flagship powerhouses...",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHBob25lJTIwYnV5aW5nJTIwZ3VpZGV8ZW58MXx8fHwxNzU4MjE5NTM5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Sarah Johnson",
    readTime: "15 min read"
  },
  {
    id: 3,
    type: "news",
    title: "Apple Announces Revolutionary M4 Chip with AI Acceleration",
    category: "News",
    excerpt: "Apple's latest M4 chip promises 50% better AI performance and enhanced neural engine capabilities...",
    image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBcHBsZSUyME00JTIwY2hpcCUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzU4MjE5NTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Sarah Johnson",
    readTime: "5 min read",
    publishDate: "2025-01-18"
  },
  {
    id: 4,
    type: "review",
    title: "MacBook Pro M3 Max: Professional Powerhouse",
    category: "Laptops",
    excerpt: "Apple's most powerful laptop delivers unprecedented performance for creative professionals...",
    image: "https://images.unsplash.com/photo-1629491697442-7d67fc25d897?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxNYWNCb29rJTIwUHJvJTIwbGFwdG9wfGVufDF8fHx8MTc1ODE2NzQyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Sarah Johnson",
    rating: 4.9,
    readTime: "15 min read",
    price: "$3,999"
  },
  {
    id: 5,
    type: "review",
    title: "Sony WH-1000XM5: ANC Excellence Redefined",
    category: "Audio",
    excerpt: "Sony's flagship noise-canceling headphones deliver industry-leading ANC and exceptional sound quality...",
    image: "https://images.unsplash.com/photo-1632200004922-bc18602c79fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aXJlbGVzcyUyMGhlYWRwaG9uZXMlMjBhdWRpb3xlbnwxfHx8fDE3NTgxODI2MDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    author: "Alex Chen",
    rating: 4.8,
    readTime: "12 min read",
    price: "$399"
  }
];

const filters = [
  "All",
  "Reviews", 
  "Buying Guides",
  "News",
  "Smartphones",
  "Laptops",
  "Audio",
  "Gaming",
  "Cameras"
];

interface SearchPageProps {
  onBack: () => void;
  initialQuery?: string;
}

export function SearchPage({ onBack, initialQuery = "" }: SearchPageProps) {
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  const filteredResults = searchResults.filter(result => {
    const matchesSearch = searchTerm === "" || 
      result.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      result.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      result.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = activeFilters.length === 0 || 
      activeFilters.some(filter => 
        filter === "All" || 
        result.type === filter.toLowerCase().replace(" ", "") ||
        result.category === filter
      );
    
    return matchesSearch && matchesFilter;
  });

  const toggleFilter = (filter: string) => {
    if (filter === "All") {
      setActiveFilters([]);
    } else {
      setActiveFilters(prev => 
        prev.includes(filter) 
          ? prev.filter(f => f !== filter)
          : [...prev, filter]
      );
    }
  };

  const clearFilters = () => {
    setActiveFilters([]);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Search Results</h1>
                <p className="text-sm text-muted-foreground">
                  {filteredResults.length} results found
                  {searchTerm && ` for "${searchTerm}"`}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search reviews, guides, news..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 pr-4 py-3 text-base"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            {activeFilters.length > 0 && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                <X className="h-3 w-3 mr-1" />
                Clear All
              </Button>
            )}
          </div>
          
          <div className="flex flex-wrap gap-2">
            {filters.map((filter) => (
              <Button
                key={filter}
                variant={
                  (filter === "All" && activeFilters.length === 0) || 
                  activeFilters.includes(filter) 
                    ? "default" 
                    : "outline"
                }
                size="sm"
                onClick={() => toggleFilter(filter)}
                className="text-sm"
              >
                {filter}
              </Button>
            ))}
          </div>
        </div>

        {/* Search Results */}
        {filteredResults.length === 0 ? (
          <div className="text-center py-12">
            <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No results found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search terms or filters
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredResults.map((result) => (
              <Card key={result.id} className="overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer">
                <div className="grid md:grid-cols-4 gap-0">
                  {/* Image */}
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <ImageWithFallback 
                      src={result.image}
                      alt={result.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge variant="secondary">
                        {result.category}
                      </Badge>
                      <Badge className={
                        result.type === "review" ? "bg-blue-500" :
                        result.type === "guide" ? "bg-green-500" : "bg-orange-500"
                      }>
                        {result.type === "review" ? "Review" :
                         result.type === "guide" ? "Guide" : "News"}
                      </Badge>
                    </div>
                    {result.price && (
                      <div className="absolute bottom-4 right-4 bg-black/80 text-white px-2 py-1 rounded text-sm">
                        {result.price}
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <CardContent className="p-6 md:col-span-3">
                    {result.rating && (
                      <div className="flex items-center space-x-2 mb-3">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${
                                i < Math.floor(result.rating!) 
                                  ? 'fill-yellow-400 text-yellow-400' 
                                  : 'text-gray-300'
                              }`} 
                            />
                          ))}
                        </div>
                        <span className="text-sm font-medium">{result.rating}/5</span>
                      </div>
                    )}
                    
                    <h3 className="text-lg font-semibold mb-3 group-hover:text-primary transition-colors">
                      {result.title}
                    </h3>
                    
                    <p className="text-muted-foreground mb-4 line-clamp-2">
                      {result.excerpt}
                    </p>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{result.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{result.readTime}</span>
                        </div>
                        {result.publishDate && (
                          <span>{new Date(result.publishDate).toLocaleDateString()}</span>
                        )}
                      </div>
                      <Button variant="ghost" size="sm">
                        Read {result.type === "review" ? "Review" : result.type === "guide" ? "Guide" : "Article"}
                      </Button>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Load More */}
        {filteredResults.length > 0 && (
          <div className="text-center mt-12">
            <Button variant="outline">
              Load More Results
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}