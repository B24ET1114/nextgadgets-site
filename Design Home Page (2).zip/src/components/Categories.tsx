import { memo } from "react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Smartphone, 
  Laptop, 
  Headphones, 
  Watch, 
  Camera, 
  Gamepad2,
  Tablet,
  Home
} from "lucide-react";
import categoryLogos from "figma:asset/82764415d74984ad28f73608ee711fe859d06ed4.png";

interface CategoriesProps {
  onNavigate?: (page: string) => void;
}

const categories = [
  {
    id: 1,
    name: "Smartphones",
    icon: Smartphone,
    count: "145 Reviews",
    description: "Latest iPhone, Android, and flagship phone reviews",
    color: "from-blue-500 to-blue-600",
    bgColor: "bg-gradient-to-br from-blue-500/20 to-blue-600/10",
    shadowColor: "shadow-blue-500/25"
  },
  {
    id: 2,
    name: "Laptops",
    icon: Laptop,
    count: "89 Reviews",
    description: "MacBooks, Windows laptops, and Chromebooks",
    color: "from-green-500 to-green-600",
    bgColor: "bg-gradient-to-br from-green-500/20 to-green-600/10",
    shadowColor: "shadow-green-500/25"
  },
  {
    id: 3,
    name: "Audio",
    icon: Headphones,
    count: "124 Reviews",
    description: "Headphones, earbuds, speakers, and sound systems",
    color: "from-purple-500 to-purple-600",
    bgColor: "bg-gradient-to-br from-purple-500/20 to-purple-600/10",
    shadowColor: "shadow-purple-500/25"
  },
  {
    id: 4,
    name: "Wearables",
    icon: Watch,
    count: "67 Reviews",
    description: "Smartwatches, fitness trackers, and health devices",
    color: "from-orange-500 to-orange-600",
    bgColor: "bg-gradient-to-br from-orange-500/20 to-orange-600/10",
    shadowColor: "shadow-orange-500/25"
  },
  {
    id: 5,
    name: "Cameras",
    icon: Camera,
    count: "52 Reviews",
    description: "DSLRs, mirrorless cameras, and photography gear",
    color: "from-red-500 to-red-600",
    bgColor: "bg-gradient-to-br from-red-500/20 to-red-600/10",
    shadowColor: "shadow-red-500/25"
  },
  {
    id: 6,
    name: "Gaming",
    icon: Gamepad2,
    count: "78 Reviews",
    description: "Gaming laptops, consoles, and accessories",
    color: "from-indigo-500 to-indigo-600",
    bgColor: "bg-gradient-to-br from-indigo-500/20 to-indigo-600/10",
    shadowColor: "shadow-indigo-500/25"
  },
  {
    id: 7,
    name: "Tablets",
    icon: Tablet,
    count: "43 Reviews",
    description: "iPads, Android tablets, and 2-in-1 devices",
    color: "from-cyan-500 to-cyan-600",
    bgColor: "bg-gradient-to-br from-cyan-500/20 to-cyan-600/10",
    shadowColor: "shadow-cyan-500/25"
  },
  {
    id: 8,
    name: "Smart Home",
    icon: Home,
    count: "91 Reviews",
    description: "Smart speakers, home automation, and IoT devices",
    color: "from-pink-500 to-pink-600",
    bgColor: "bg-gradient-to-br from-pink-500/20 to-pink-600/10",
    shadowColor: "shadow-pink-500/25"
  }
];

export const Categories = memo(function Categories({ onNavigate }: CategoriesProps) {
  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Futuristic Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-muted/5 to-background"></div>
      
      {/* Animated Grid Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent animate-pulse"></div>
        <div 
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage: `
              linear-gradient(rgba(3,2,19,0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(3,2,19,0.1) 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px',
            animation: 'gridMove 20s ease-in-out infinite'
          }}
        ></div>
      </div>

      {/* Floating Orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-32 h-32 bg-blue-500/10 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-purple-500/10 rounded-full blur-lg animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 left-1/3 w-28 h-28 bg-green-500/10 rounded-full blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute bottom-32 right-1/4 w-20 h-20 bg-orange-500/10 rounded-full blur-lg animate-pulse" style={{ animationDelay: '3s' }}></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <Badge variant="secondary" className="mb-8 glass hover-scale interactive animate-fade-in-up text-sm px-6 py-2 border border-primary/20 bg-gradient-to-r from-primary/10 to-primary/5 badge-text-safe">
            <span className="text-primary force-primary">Browse Categories</span>
          </Badge>
          <h2 className="text-4xl md:text-6xl mb-8 animate-fade-in-up text-foreground force-visible" style={{ animationDelay: '0.2s' }}>
            Explore by Category
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto animate-fade-in-up leading-relaxed" style={{ animationDelay: '0.4s' }}>
            Discover comprehensive reviews and expert guides for every type of tech product in our futuristic tech ecosystem.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {categories.map((category, index) => {
            const IconComponent = category.icon;
            const handleClick = () => {
              switch (category.name) {
                case "Smartphones":
                  onNavigate?.("smartphones");
                  break;
                case "Laptops":
                  onNavigate?.("laptops");
                  break;
                case "Audio":
                  onNavigate?.("audio");
                  break;
                case "Wearables":
                  onNavigate?.("wearables");
                  break;
                case "Cameras":
                  onNavigate?.("cameras");
                  break;
                case "Gaming":
                  onNavigate?.("gaming");
                  break;
                case "Tablets":
                  onNavigate?.("tablets");
                  break;
                case "Smart Home":
                  onNavigate?.("smarthome");
                  break;
              }
            };
            
            return (
              <Card 
                key={category.id} 
                className="group relative overflow-hidden cursor-pointer interactive animate-fade-in-up border-0"
                style={{ 
                  animationDelay: `${0.6 + index * 0.15}s`,
                  background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.02) 100%)',
                  backdropFilter: 'blur(30px) saturate(200%)',
                  transition: 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
                onClick={handleClick}
              >
                {/* Futuristic Border */}
                <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-transparent via-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                <div className="absolute inset-[1px] rounded-lg bg-gradient-to-br from-background/90 to-background/70 backdrop-blur-xl"></div>
                
                {/* Neon Glow Effect */}
                <div 
                  className={`absolute inset-0 rounded-lg opacity-0 group-hover:opacity-60 transition-all duration-700 blur-xl`}
                  style={{
                    background: `linear-gradient(135deg, ${category.color.replace('from-', '').replace('to-', '').split(' ')[0]?.replace('-500', '')}-500/30, ${category.color.replace('from-', '').replace('to-', '').split(' ')[1]?.replace('-600', '')}-600/20)`
                  }}
                ></div>

                <CardContent className="p-10 text-center relative z-10">
                  {/* Futuristic Icon Container */}
                  <div className="mb-8 relative">
                    {/* Rotating Ring */}
                    <div className="absolute inset-0 w-24 h-24 mx-auto">
                      <div className="absolute inset-0 rounded-full border border-primary/20 group-hover:border-primary/40 transition-colors duration-700 group-hover:animate-spin" style={{ animationDuration: '8s' }}></div>
                      <div className="absolute inset-2 rounded-full border border-primary/10 group-hover:border-primary/30 transition-colors duration-700 group-hover:animate-spin" style={{ animationDirection: 'reverse', animationDuration: '12s' }}></div>
                    </div>
                    
                    {/* Main Icon Container */}
                    <div className={`relative bg-gradient-to-br ${category.color} text-white rounded-3xl p-6 w-24 h-24 mx-auto group-hover:scale-110 group-hover:rotate-6 transition-all duration-700 shadow-2xl`}>
                      {/* Holographic Effect */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-white/30 via-transparent to-transparent rounded-3xl opacity-60"></div>
                      <div className="absolute inset-0 bg-gradient-to-bl from-transparent via-transparent to-black/20 rounded-3xl"></div>
                      
                      {/* Icon */}
                      <IconComponent 
                        className="h-12 w-12 relative z-10 drop-shadow-2xl group-hover:drop-shadow-[0_0_20px_rgba(255,255,255,0.5)] transition-all duration-700" 
                        strokeWidth={1.2} 
                      />
                      
                      {/* Pulsing Glow */}
                      <div className={`absolute inset-0 bg-gradient-to-br ${category.color} rounded-3xl blur-2xl opacity-0 group-hover:opacity-50 transition-all duration-700 animate-pulse scale-150`}></div>
                    </div>
                  </div>
                  
                  {/* Category Name */}
                  <h3 className="text-xl mb-4 group-hover:text-primary transition-all duration-500 force-visible">
                    {category.name}
                  </h3>
                  
                  {/* Description */}
                  <p className="text-sm text-muted-foreground mb-6 leading-relaxed group-hover:text-muted-foreground/80 transition-colors duration-500">
                    {category.description}
                  </p>
                  
                  {/* Enhanced Badge */}
                  <Badge 
                    variant="outline" 
                    className="text-xs px-4 py-1 border-primary/20 bg-gradient-to-r from-primary/10 to-primary/5 hover:from-primary/20 hover:to-primary/10 transition-all duration-500 group-hover:scale-105 badge-text-safe"
                  >
                    <span className="text-primary force-primary">
                      {category.count}
                    </span>
                  </Badge>
                  
                  {/* Particle Effect */}
                  <div className="absolute top-4 right-4 w-2 h-2 bg-primary/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 group-hover:animate-ping"></div>
                  <div className="absolute bottom-4 left-4 w-1 h-1 bg-primary/30 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 group-hover:animate-ping" style={{ animationDelay: '0.5s' }}></div>
                </CardContent>

                {/* Hover Scan Line Effect */}
                <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-primary to-transparent translate-y-0 group-hover:translate-y-full transition-transform duration-1000 ease-in-out"></div>
              </Card>
            );
          })}
        </div>
        
        {/* Reference to original design (hidden but preserved for context) */}
        <div className="hidden">
          <img src={categoryLogos} alt="Category logos reference" />
        </div>
      </div>

      <style jsx>{`
        @keyframes gridMove {
          0%, 100% { transform: translate(0, 0); }
          25% { transform: translate(10px, 10px); }
          50% { transform: translate(-5px, 15px); }
          75% { transform: translate(15px, -10px); }
        }
      `}</style>
    </section>
  );
});