import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Search,
  Star,
  Clock,
  User,
  ArrowLeft,
  TrendingUp,
  Award,
  DollarSign,
  Zap,
  Volume2,
  Headphones,
  Mic,
  Bluetooth,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const audioReviews = [
  {
    id: 1,
    title: "Sony WH-1000XM5: Noise Cancelling King",
    brand: "Sony",
    model: "WH-1000XM5",
    price: "$399",
    rating: 4.8,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "Sony's flagship wireless headphones deliver industry-leading noise cancellation and exceptional sound quality in a redesigned package...",
    fullReview:
      "The WH-1000XM5 represents Sony's most refined wireless headphone experience to date. The new design is sleeker and more comfortable for extended listening sessions. The V1 processor and dual noise sensor technology provide the best active noise cancellation available today. Sound quality is exceptional with Sony's signature warm sound profile that can be customized via the Sony Headphones app. Battery life of 30 hours with ANC on is industry-leading.",
    specs: {
      type: "Over-ear Wireless",
      driver: "30mm Dynamic",
      frequency: "4Hz - 40kHz",
      impedance: "48Ω",
      battery: "30 hours (ANC on), 40 hours (ANC off)",
      connectivity: "Bluetooth 5.2, 3.5mm wired",
      weight: "250g",
    },
    pros: [
      "Best-in-class noise cancellation",
      "Exceptional sound quality",
      "30-hour battery life",
      "Comfortable design",
      "Quick charge feature",
    ],
    cons: [
      "Expensive",
      "No aptX support",
      "Touch controls can be finicky",
      "Case is bulky",
    ],
    author: "NextGadgets Team",
    readTime: "12 min read",
    category: "Wireless",
    featured: true,
    score: {
      sound: 9.5,
      comfort: 9.0,
      anc: 10.0,
      battery: 9.5,
      value: 8.0,
    },
  },
  {
    id: 2,
    title: "Apple AirPods Pro (3rd Gen): Seamless Integration",
    brand: "Apple",
    model: "AirPods Pro (3rd Gen)",
    price: "$249",
    rating: 4.6,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "Apple's premium earbuds offer exceptional integration with iOS devices and impressive spatial audio capabilities...",
    fullReview:
      "The AirPods Pro (3rd Gen) showcase Apple's mastery of the true wireless earbud format. The H2 chip delivers improved active noise cancellation and transparency mode. Spatial Audio with head tracking provides an immersive listening experience that's particularly impressive with Apple's own content. The seamless integration with Apple devices makes these earbuds incredibly convenient for iPhone users. Sound quality is balanced and detailed, though not quite audiophile-level.",
    specs: {
      type: "True Wireless Earbuds",
      driver: "Custom Dynamic",
      frequency: "20Hz - 20kHz",
      battery: "6 hours + 30 hours (case)",
      connectivity: "Bluetooth 5.3",
      waterResistance: "IPX4",
      weight: "5.3g per earbud",
    },
    pros: [
      "Seamless Apple ecosystem integration",
      "Excellent spatial audio",
      "Good ANC for earbuds",
      "Comfortable fit",
      "MagSafe charging case",
    ],
    cons: [
      "Expensive",
      "Best with Apple devices only",
      "Short battery per charge",
      "Easy to lose",
    ],
    author: "NextGadgets Team",
    readTime: "10 min read",
    category: "True Wireless",
    score: {
      sound: 8.5,
      comfort: 8.5,
      anc: 8.5,
      battery: 8.0,
      value: 7.5,
    },
  },
  {
    id: 3,
    title: "Sennheiser HD 650: Audiophile Reference",
    brand: "Sennheiser",
    model: "HD 650",
    price: "$499",
    rating: 4.7,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "The legendary open-back headphones continue to set the standard for audiophile listening with their natural, detailed sound signature...",
    fullReview:
      "The HD 650 represents decades of Sennheiser's acoustic engineering expertise in a timeless design. These open-back headphones deliver a natural, reference-quality sound signature that reveals every detail in your music. The 300-ohm impedance means they benefit from a good headphone amplifier, but the reward is exceptional clarity and dynamics. Build quality is excellent with replaceable parts ensuring these headphones can last decades.",
    specs: {
      type: "Open-back Wired",
      driver: "38mm Dynamic Transducer",
      frequency: "10Hz - 41kHz",
      impedance: "300Ω",
      sensitivity: "103 dB",
      connectivity: "6.3mm jack (3.5mm adapter included)",
      weight: "260g",
    },
    pros: [
      "Reference-quality sound",
      "Exceptional detail retrieval",
      "Comfortable for long sessions",
      "Excellent build quality",
      "Replaceable parts",
    ],
    cons: [
      "Requires amplification",
      "Open-back design leaks sound",
      "Not portable",
      "Expensive",
    ],
    author: "NextGadgets Team",
    readTime: "11 min read",
    category: "Wired",
    score: {
      sound: 10.0,
      comfort: 9.0,
      anc: 0.0,
      battery: 0.0,
      value: 8.5,
    },
  },
  {
    id: 4,
    title: "Bose QuietComfort 45: Comfort Champion",
    brand: "Bose",
    model: "QuietComfort 45",
    price: "$329",
    rating: 4.5,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "Bose delivers exceptional comfort and reliable noise cancellation in a familiar design that prioritizes all-day wearability...",
    fullReview:
      "The QuietComfort 45 continues Bose's tradition of exceptionally comfortable headphones with effective noise cancellation. While not quite matching Sony's latest ANC technology, the QC45 still provides excellent isolation for travel and work. The sound signature is balanced and pleasant, if not particularly exciting. Build quality is solid, and the 24-hour battery life is more than adequate for most users. The simple, reliable design appeals to those who prioritize comfort over flashy features.",
    specs: {
      type: "Over-ear Wireless",
      driver: "TriPort Acoustic Architecture",
      frequency: "Not specified",
      impedance: "Not specified",
      battery: "24 hours",
      connectivity: "Bluetooth 5.1, 3.5mm wired",
      weight: "238g",
    },
    pros: [
      "Exceptional comfort",
      "Reliable noise cancellation",
      "Good battery life",
      "Simple, intuitive controls",
      "Lightweight design",
    ],
    cons: [
      "Sound quality is just okay",
      "ANC not best-in-class",
      "Limited customization",
      "Plastic build feels cheap",
    ],
    author: "NextGadgets Team",
    readTime: "9 min read",
    category: "Wireless",
    score: {
      sound: 7.5,
      comfort: 9.5,
      anc: 8.5,
      battery: 8.5,
      value: 8.0,
    },
  },
  {
    id: 5,
    title: "Audio-Technica ATH-M50x: Studio Standard",
    brand: "Audio-Technica",
    model: "ATH-M50x",
    price: "$149",
    rating: 4.4,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "The industry-standard studio monitor headphones deliver professional-grade sound quality at an accessible price point...",
    fullReview:
      "The ATH-M50x has earned its reputation as a studio standard through consistent performance and excellent value. The closed-back design provides good isolation, making them suitable for both studio monitoring and portable use. Sound quality is detailed and accurate with a slight bass emphasis that flatters most music genres. Build quality is robust enough for professional use, with detachable cables adding to their durability and convenience.",
    specs: {
      type: "Closed-back Wired",
      driver: "45mm Large-aperture Dynamic",
      frequency: "15Hz - 28kHz",
      impedance: "38Ω",
      sensitivity: "99 dB/mW",
      connectivity: "Detachable cables (3.5mm, 6.3mm, coiled)",
      weight: "285g",
    },
    pros: [
      "Professional sound quality",
      "Excellent value",
      "Detachable cables",
      "Robust build quality",
      "Good isolation",
    ],
    cons: [
      "Can be fatiguing for long sessions",
      "Not the most comfortable",
      "Cable can be heavy",
      "Limited soundstage",
    ],
    author: "NextGadgets Team",
    readTime: "8 min read",
    category: "Wired",
    score: {
      sound: 9.0,
      comfort: 7.0,
      anc: 0.0,
      battery: 0.0,
      value: 9.5,
    },
  },
  {
    id: 6,
    title: "Beyerdynamic DT 990 Pro: Open-back Excellence",
    brand: "Beyerdynamic",
    model: "DT 990 Pro",
    price: "$179",
    rating: 4.3,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "German engineering delivers exceptional soundstage and detail in these professional open-back studio headphones...",
    fullReview:
      "The DT 990 Pro showcases Beyerdynamic's expertise in open-back headphone design. The spacious soundstage and excellent detail retrieval make them ideal for critical listening and audio production. The Tesla drivers provide exceptional clarity and dynamics. The velour earpads are comfortable for extended sessions, though the headphones can become warm during long use. The coiled cable is sturdy but can be cumbersome for some users.",
    specs: {
      type: "Open-back Wired",
      driver: "45mm Tesla Dynamic",
      frequency: "5Hz - 35kHz",
      impedance: "250Ω",
      sensitivity: "96 dB",
      connectivity: "3.5mm jack with 6.3mm adapter",
      weight: "290g",
    },
    pros: [
      "Excellent soundstage",
      "Great detail retrieval",
      "Comfortable velour pads",
      "Professional build quality",
      "Good value",
    ],
    cons: [
      "Requires amplification",
      "Can be bright for some",
      "Open design leaks sound",
      "Fixed cable",
    ],
    author: "NextGadgets Team",
    readTime: "9 min read",
    category: "Wired",
    score: {
      sound: 9.0,
      comfort: 8.5,
      anc: 0.0,
      battery: 0.0,
      value: 8.5,
    },
  },
  {
    id: 7,
    title: "Shure SM7B: Podcast Professional",
    brand: "Shure",
    model: "SM7B",
    price: "$399",
    rating: 4.8,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "The legendary broadcast microphone that's become the gold standard for podcasting and professional vocal recording...",
    fullReview:
      "The SM7B has achieved legendary status in the podcasting world for good reason. Its dynamic design provides excellent background noise rejection while delivering warm, professional vocal quality. The built-in shock mounting reduces handling noise, and the pop filter helps control plosives. While it requires significant gain from an audio interface or cloudlifter, the results are broadcast-quality recordings that sound professional without extensive post-processing.",
    specs: {
      type: "Dynamic Broadcast Microphone",
      frequency: "50Hz - 20kHz",
      pattern: "Cardioid",
      impedance: "150Ω",
      sensitivity: "-59 dBV/Pa",
      connectivity: "XLR",
      weight: "765g",
    },
    pros: [
      "Broadcast-quality sound",
      "Excellent noise rejection",
      "Built-in shock mounting",
      "Professional build quality",
      "Industry standard",
    ],
    cons: [
      "Requires lots of gain",
      "Expensive",
      "Heavy",
      "Needs audio interface",
    ],
    author: "NextGadgets Team",
    readTime: "10 min read",
    category: "Microphone",
    score: {
      sound: 9.8,
      comfort: 8.0,
      anc: 9.5,
      battery: 0.0,
      value: 8.0,
    },
  },
  {
    id: 8,
    title: "HiFiMan Sundara: Planar Magnetic Marvel",
    brand: "HiFiMan",
    model: "Sundara",
    price: "$349",
    rating: 4.6,
    image:
      "https://images.unsplash.com/photo-1737885197946-6d9d79dade89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGF1ZGlvJTIwZGV2aWNlfGVufDF8fHx8MTc1ODMwNjg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt:
      "Affordable planar magnetic headphones that deliver exceptional detail and speed with a neutral, engaging sound signature...",
    fullReview:
      "The Sundara brings planar magnetic technology to a more accessible price point without significant compromises. The ultra-thin diaphragm delivers exceptional speed and detail retrieval that dynamic drivers struggle to match. The neutral sound signature makes them excellent for critical listening across all genres. Build quality has improved significantly over previous HiFiMan models, though comfort can vary depending on head size and shape.",
    specs: {
      type: "Open-back Planar Magnetic",
      driver: "Planar Magnetic",
      frequency: "6Hz - 75kHz",
      impedance: "37Ω",
      sensitivity: "94 dB",
      connectivity: "3.5mm detachable cable",
      weight: "372g",
    },
    pros: [
      "Planar magnetic detail",
      "Neutral sound signature",
      "Good value for technology",
      "Detachable cable",
      "Wide frequency response",
    ],
    cons: [
      "Can be uncomfortable",
      "Requires good amplification",
      "Build quality concerns",
      "Heavy",
    ],
    author: "NextGadgets Team",
    readTime: "11 min read",
    category: "Wired",
    score: {
      sound: 9.5,
      comfort: 7.0,
      anc: 0.0,
      battery: 0.0,
      value: 8.5,
    },
  },
];

const buyingGuides = [
  {
    id: 1,
    title: "Best Headphones Under $200 (2025)",
    description:
      "Top budget headphones that deliver great sound",
    icon: DollarSign,
    color: "bg-green-500",
  },
  {
    id: 2,
    title: "Wireless vs Wired: Complete Guide",
    description:
      "Everything you need to know about audio connections",
    icon: Bluetooth,
    color: "bg-blue-500",
  },
  {
    id: 3,
    title: "Gaming Headset Buyer's Guide",
    description: "Best headsets for competitive gaming",
    icon: Zap,
    color: "bg-purple-500",
  },
  {
    id: 4,
    title: "Audiophile Headphone Guide",
    description: "High-end headphones for serious listeners",
    icon: Award,
    color: "bg-red-500",
  },
  {
    id: 5,
    title: "Microphone Setup Guide",
    description: "Professional audio recording at home",
    icon: Mic,
    color: "bg-orange-500",
  },
  {
    id: 6,
    title: "Noise Cancelling Comparison",
    description: "Best ANC headphones for travel and work",
    icon: Volume2,
    color: "bg-indigo-500",
  },
];

interface AudioPageProps {
  onBack: () => void;
}

export function AudioPage({ onBack }: AudioPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("all");
  const [selectedCategory, setSelectedCategory] =
    useState("all");
  const [selectedReview, setSelectedReview] =
    useState<any>(null);

  const filteredReviews = audioReviews.filter((review) => {
    const matchesSearch =
      review.title
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      review.brand
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
    const matchesBrand =
      selectedBrand === "all" ||
      review.brand.toLowerCase() === selectedBrand;
    const matchesCategory =
      selectedCategory === "all" ||
      review.category.toLowerCase() === selectedCategory;

    return matchesSearch && matchesBrand && matchesCategory;
  });

  if (selectedReview) {
    return (
      <div className="min-h-screen bg-background">
        <div className="border-b bg-background/95 backdrop-blur sticky top-0 z-40">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedReview(null)}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Badge variant="secondary">Full Review</Badge>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="aspect-[16/9] relative overflow-hidden rounded-xl mb-8">
              <ImageWithFallback
                src={selectedReview.image}
                alt={selectedReview.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <Badge className="bg-black/80 text-white">
                  {selectedReview.brand}
                </Badge>
                <Badge variant="secondary">
                  {selectedReview.category}
                </Badge>
              </div>
              <div className="absolute bottom-4 right-4 bg-black/80 text-white px-4 py-2 rounded-full font-medium">
                {selectedReview.price}
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-4">
                  {selectedReview.title}
                </h1>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground mb-6">
                  <div className="flex items-center space-x-1">
                    <User className="h-4 w-4" />
                    <span>{selectedReview.author}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{selectedReview.readTime}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i <
                            Math.floor(selectedReview.rating)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="font-medium">
                      {selectedReview.rating}/5
                    </span>
                  </div>
                </div>
              </div>

              <div className="prose max-w-none">
                <p className="text-lg leading-relaxed text-muted-foreground">
                  {selectedReview.fullReview}
                </p>
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">
                    Audio Performance Scores
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(selectedReview.score).map(
                      ([category, score]) => (
                        <div
                          key={category}
                          className="text-center"
                        >
                          <div className="text-2xl font-bold text-primary mb-1">
                            {category === "anc" ||
                            category === "battery"
                              ? score === 0
                                ? "N/A"
                                : score
                              : score}
                          </div>
                          <div className="text-sm text-muted-foreground capitalize">
                            {category === "anc"
                              ? "ANC"
                              : category}
                          </div>
                        </div>
                      ),
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">
                    Technical Specifications
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {Object.entries(selectedReview.specs).map(
                      ([key, value]) => (
                        <div
                          key={key}
                          className="flex justify-between"
                        >
                          <span className="text-muted-foreground capitalize">
                            {key
                              .replace(/([A-Z])/g, " $1")
                              .trim()}
                            :
                          </span>
                          <span className="font-medium">
                            {value}
                          </span>
                        </div>
                      ),
                    )}
                  </div>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-green-600 mb-4">
                      Pros
                    </h3>
                    <ul className="space-y-2">
                      {selectedReview.pros.map(
                        (pro: string, i: number) => (
                          <li
                            key={i}
                            className="flex items-start space-x-2"
                          >
                            <span className="text-green-500 mt-1">
                              +
                            </span>
                            <span>{pro}</span>
                          </li>
                        ),
                      )}
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-red-600 mb-4">
                      Cons
                    </h3>
                    <ul className="space-y-2">
                      {selectedReview.cons.map(
                        (con: string, i: number) => (
                          <li
                            key={i}
                            className="flex items-start space-x-2"
                          >
                            <span className="text-red-500 mt-1">
                              -
                            </span>
                            <span>{con}</span>
                          </li>
                        ),
                      )}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-background/95 backdrop-blur sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={onBack}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Audio Reviews</h1>
                <p className="text-sm text-muted-foreground">
                  Headphones, earbuds, and audio gear
                </p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              {audioReviews.length} Reviews
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="reviews" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reviews">
              Latest Reviews
            </TabsTrigger>
            <TabsTrigger value="guides">
              Buying Guides
            </TabsTrigger>
            <TabsTrigger value="comparisons">
              Comparisons
            </TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-8">
            <div className="flex flex-col md:flex-row gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search audio gear..."
                    value={searchTerm}
                    onChange={(e) =>
                      setSearchTerm(e.target.value)
                    }
                    className="pl-10"
                  />
                </div>
              </div>
              <Select
                value={selectedBrand}
                onValueChange={setSelectedBrand}
              >
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    All Brands
                  </SelectItem>
                  <SelectItem value="sony">Sony</SelectItem>
                  <SelectItem value="apple">Apple</SelectItem>
                  <SelectItem value="sennheiser">
                    Sennheiser
                  </SelectItem>
                  <SelectItem value="bose">Bose</SelectItem>
                  <SelectItem value="audio-technica">
                    Audio-Technica
                  </SelectItem>
                  <SelectItem value="beyerdynamic">
                    Beyerdynamic
                  </SelectItem>
                  <SelectItem value="shure">Shure</SelectItem>
                  <SelectItem value="hifiman">
                    HiFiMan
                  </SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={selectedCategory}
                onValueChange={setSelectedCategory}
              >
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    All Categories
                  </SelectItem>
                  <SelectItem value="wireless">
                    Wireless
                  </SelectItem>
                  <SelectItem value="true wireless">
                    True Wireless
                  </SelectItem>
                  <SelectItem value="wired">Wired</SelectItem>
                  <SelectItem value="microphone">
                    Microphone
                  </SelectItem>
                  <SelectItem value="gaming">Gaming</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {filteredReviews.map((review, index) => (
                <Card
                  key={review.id}
                  className={`overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1 ${index === 0 ? "lg:col-span-2" : ""}`}
                  onClick={() => setSelectedReview(review)}
                >
                  <div
                    className={`${index === 0 ? "aspect-[16/9]" : "aspect-[4/3]"} relative overflow-hidden`}
                  >
                    <ImageWithFallback
                      src={review.image}
                      alt={review.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className="bg-black/80 text-white">
                        {review.brand}
                      </Badge>
                      <Badge variant="secondary">
                        {review.category}
                      </Badge>
                      {review.featured && (
                        <Badge className="bg-red-500 text-white">
                          Featured
                        </Badge>
                      )}
                    </div>
                    <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {review.price}
                    </div>
                  </div>
                  <CardContent
                    className={`${index === 0 ? "p-8" : "p-6"}`}
                  >
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(review.rating)
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium">
                        {review.rating}/5
                      </span>
                    </div>
                    <h3
                      className={`${index === 0 ? "text-2xl" : "text-lg"} font-semibold mb-3 group-hover:text-primary transition-colors`}
                    >
                      {review.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 line-clamp-2">
                      {review.excerpt}
                    </p>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <h5 className="text-sm font-medium text-green-600 mb-2">
                          Pros
                        </h5>
                        <ul className="text-xs space-y-1">
                          {review.pros
                            .slice(0, 2)
                            .map((pro, i) => (
                              <li
                                key={i}
                                className="text-muted-foreground"
                              >
                                • {pro}
                              </li>
                            ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-red-600 mb-2">
                          Cons
                        </h5>
                        <ul className="text-xs space-y-1">
                          {review.cons
                            .slice(0, 2)
                            .map((con, i) => (
                              <li
                                key={i}
                                className="text-muted-foreground"
                              >
                                • {con}
                              </li>
                            ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{review.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{review.readTime}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        Read Review
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guides" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold mb-2">
                Audio Buying Guides
              </h2>
              <p className="text-muted-foreground">
                Expert advice for choosing the perfect audio
                gear
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {buyingGuides.map((guide) => {
                const IconComponent = guide.icon;
                return (
                  <Card
                    key={guide.id}
                    className="group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1"
                  >
                    <CardContent className="p-6 text-center">
                      <div
                        className={`${guide.color} text-white rounded-full p-4 w-16 h-16 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}
                      >
                        <IconComponent className="h-8 w-8" />
                      </div>
                      <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                        {guide.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        {guide.description}
                      </p>
                      <Button variant="outline" size="sm">
                        Read Guide
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="comparisons">
            <div className="text-center py-16">
              <Headphones className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-2xl font-semibold mb-2">
                Audio Comparisons
              </h2>
              <p className="text-muted-foreground mb-8">
                Detailed head-to-head audio gear comparisons
                coming soon
              </p>
              <Button>Request a Comparison</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}