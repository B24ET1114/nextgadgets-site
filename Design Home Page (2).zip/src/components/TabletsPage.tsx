import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Search, 
  Star, 
  Clock, 
  User, 
  ArrowLeft,
  TrendingUp,
  Award,
  DollarSign,
  Tablet,
  PenTool,
  Monitor
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const tabletReviews = [
  {
    id: 1,
    title: "iPad Pro M2: Creative Powerhouse",
    brand: "Apple",
    model: "iPad Pro 12.9-inch M2",
    price: "$1,099",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1672239069328-dd1535c0d78a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpUGFkJTIwdGFibGV0JTIwZGV2aWNlfGVufDF8fHx8MTc1ODIxOTIzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Apple's most powerful tablet delivers desktop-class performance with M2 chip and stunning Liquid Retina XDR display...",
    pros: ["M2 chip performance", "Stunning display quality", "Excellent Apple Pencil support"],
    cons: ["Very expensive", "iPadOS limitations", "Expensive accessories"],
    author: "Sarah Johnson",
    readTime: "14 min read",
    category: "Premium",
    featured: true
  },
  {
    id: 2,
    title: "Samsung Galaxy Tab S9 Ultra: Android Excellence",
    brand: "Samsung",
    model: "Galaxy Tab S9 Ultra",
    price: "$1,199",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhTYW1zdW5nJTIwR2FsYXh5JTIwVGFifGVufDF8fHx8MTc1ODIxOTM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Samsung's flagship Android tablet offers a massive 14.6-inch display and S Pen functionality for productivity...",
    pros: ["Huge beautiful display", "S Pen included", "Desktop-like multitasking"],
    cons: ["Very large and heavy", "Android app optimization", "Battery life"],
    author: "Mike Rodriguez",
    readTime: "11 min read",
    category: "Premium"
  },
  {
    id: 3,
    title: "iPad Air 5: The Sweet Spot",
    brand: "Apple",
    model: "iPad Air 5th Gen",
    price: "$599",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhpUGFkJTIwQWlyJTIwdGFibGV0fGVufDF8fHx8MTc1ODIxOTM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Apple's mid-range tablet strikes the perfect balance between performance and price with M1 chip power...",
    pros: ["M1 chip performance", "Great value proposition", "Excellent build quality"],
    cons: ["No promotion display", "Limited storage options", "First-gen Apple Pencil"],
    author: "Tech Reviewer",
    readTime: "9 min read",
    category: "Mid-Range"
  },
  {
    id: 4,
    title: "Amazon Fire HD 10: Budget Champion",
    brand: "Amazon",
    model: "Fire HD 10",
    price: "$149",
    rating: 4.2,
    image: "https://images.unsplash.com/photo-1555952494-efd681c7e3f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhBbWF6b24lMjBGaXJlJTIwdGFibGV0fGVufDF8fHx8MTc1ODIxOTM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Amazon's budget tablet delivers solid performance for media consumption and reading at an unbeatable price...",
    pros: ["Very affordable", "Good for media consumption", "Alexa integration"],
    cons: ["Limited app ecosystem", "Basic build quality", "Performance limitations"],
    author: "David Kim",
    readTime: "7 min read",
    category: "Budget"
  }
];

const buyingGuides = [
  {
    id: 1,
    title: "iPad vs Android Tablet Guide",
    description: "Complete comparison of tablet ecosystems",
    icon: Tablet,
    color: "bg-blue-500"
  },
  {
    id: 2,
    title: "Digital Art Tablet Guide",
    description: "Best tablets for drawing and design",
    icon: PenTool,
    color: "bg-purple-500"
  },
  {
    id: 3,
    title: "Productivity Tablet Setup",
    description: "Tablets that can replace laptops",
    icon: Monitor,
    color: "bg-green-500"
  },
  {
    id: 4,
    title: "Budget Tablet Recommendations",
    description: "Great tablets under $300",
    icon: DollarSign,
    color: "bg-orange-500"
  },
  {
    id: 5,
    title: "Best Tablet Accessories",
    description: "Keyboards, styluses, and cases",
    icon: Award,
    color: "bg-red-500"
  }
];

interface TabletsPageProps {
  onBack: () => void;
}

export function TabletsPage({ onBack }: TabletsPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredReviews = tabletReviews.filter(review => {
    const matchesSearch = review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === "all" || review.brand.toLowerCase() === selectedBrand;
    const matchesCategory = selectedCategory === "all" || review.category.toLowerCase().replace("-", "") === selectedCategory;
    
    return matchesSearch && matchesBrand && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Tablets</h1>
                <p className="text-sm text-muted-foreground">Latest tablet reviews and buying guides</p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              {tabletReviews.length} Reviews
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="reviews" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reviews">Latest Reviews</TabsTrigger>
            <TabsTrigger value="guides">Buying Guides</TabsTrigger>
            <TabsTrigger value="comparisons">Comparisons</TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-8">
            {/* Filters */}
            <div className="flex flex-col md:flex-row gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search tablets..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedBrand} onValueChange={setSelectedBrand}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  <SelectItem value="apple">Apple</SelectItem>
                  <SelectItem value="samsung">Samsung</SelectItem>
                  <SelectItem value="amazon">Amazon</SelectItem>
                  <SelectItem value="microsoft">Microsoft</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="premium">Premium</SelectItem>
                  <SelectItem value="midrange">Mid-Range</SelectItem>
                  <SelectItem value="budget">Budget</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Reviews Grid */}
            <div className="grid lg:grid-cols-2 gap-8">
              {filteredReviews.map((review, index) => (
                <Card key={review.id} className={`overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1 ${index === 0 ? 'lg:col-span-2' : ''}`}>
                  <div className={`${index === 0 ? 'aspect-[16/9]' : 'aspect-[4/3]'} relative overflow-hidden`}>
                    <ImageWithFallback 
                      src={review.image}
                      alt={review.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className="bg-black/80 text-white">
                        {review.brand}
                      </Badge>
                      <Badge variant="secondary">
                        {review.category}
                      </Badge>
                      {review.featured && (
                        <Badge className="bg-red-500 text-white">
                          Featured
                        </Badge>
                      )}
                    </div>
                    <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {review.price}
                    </div>
                  </div>
                  <CardContent className={`${index === 0 ? 'p-8' : 'p-6'}`}>
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${
                              i < Math.floor(review.rating) 
                                ? 'fill-yellow-400 text-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium">{review.rating}/5</span>
                    </div>
                    <h3 className={`${index === 0 ? 'text-2xl' : 'text-lg'} font-semibold mb-3 group-hover:text-primary transition-colors`}>
                      {review.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 line-clamp-2">{review.excerpt}</p>
                    
                    {/* Pros & Cons */}
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <h5 className="text-sm font-medium text-green-600 mb-2">Pros</h5>
                        <ul className="text-xs space-y-1">
                          {review.pros.slice(0, 2).map((pro, i) => (
                            <li key={i} className="text-muted-foreground">• {pro}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-red-600 mb-2">Cons</h5>
                        <ul className="text-xs space-y-1">
                          {review.cons.slice(0, 2).map((con, i) => (
                            <li key={i} className="text-muted-foreground">• {con}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{review.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{review.readTime}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">Read Full Review</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guides" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold mb-2">Tablet Buying Guides</h2>
              <p className="text-muted-foreground">Expert advice to help you choose the perfect tablet</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {buyingGuides.map((guide) => {
                const IconComponent = guide.icon;
                return (
                  <Card key={guide.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                    <CardContent className="p-6 text-center">
                      <div className={`${guide.color} text-white rounded-full p-4 w-16 h-16 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <IconComponent className="h-8 w-8" />
                      </div>
                      <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                        {guide.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        {guide.description}
                      </p>
                      <Button variant="outline" size="sm">Read Guide</Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="comparisons">
            <div className="text-center py-16">
              <h2 className="text-2xl font-semibold mb-2">Tablet Comparisons</h2>
              <p className="text-muted-foreground mb-8">Coming soon - detailed tablet comparisons</p>
              <Button>Request a Comparison</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}