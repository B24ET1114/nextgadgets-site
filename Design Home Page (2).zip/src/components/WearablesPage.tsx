import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Search, 
  Star, 
  Clock, 
  User, 
  ArrowLeft,
  TrendingUp,
  Award,
  DollarSign,
  Activity,
  Heart,
  Zap
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const wearableReviews = [
  {
    id: 1,
    title: "Apple Watch Series 9: The Smart Choice",
    brand: "Apple",
    model: "Apple Watch Series 9",
    price: "$399",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1598516802414-50a01bee818d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBcHBsZSUyMFdhdGNoJTIwc21hcnR3YXRjaHxlbnwxfHx8fDE3NTgyMTkyMzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Apple's latest smartwatch continues to set the standard with S9 chip performance and new health features...",
    pros: ["Excellent iOS integration", "Comprehensive health tracking", "Premium build quality"],
    cons: ["Limited Android compatibility", "Daily charging required", "Expensive"],
    author: "Sarah Johnson",
    readTime: "11 min read",
    category: "Smartwatch",
    featured: true
  },
  {
    id: 2,
    title: "Samsung Galaxy Watch 6: Android's Champion",
    brand: "Samsung",
    model: "Galaxy Watch 6",
    price: "$329",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1579586337278-3f436f25d4d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTYW1zdW5nJTIwR2FsYXh5JTIwV2F0Y2h8ZW58MXx8fHwxNzU4MjE5MjgzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Samsung's flagship wearable offers excellent Android integration and comprehensive fitness tracking...",
    pros: ["Great Android compatibility", "Accurate fitness tracking", "Good battery life"],
    cons: ["Limited iOS features", "Wear OS learning curve", "Bulky for small wrists"],
    author: "Mike Rodriguez",
    readTime: "9 min read",
    category: "Smartwatch"
  },
  {
    id: 3,
    title: "Garmin Forerunner 965: Running Perfection",
    brand: "Garmin",
    model: "Forerunner 965",
    price: "$599",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxHYXJtaW4lMjBydW5uaW5nJTIwd2F0Y2h8ZW58MXx8fHwxNzU4MjE5Mjg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Garmin's premium running watch delivers unmatched GPS accuracy and training metrics for serious athletes...",
    pros: ["Exceptional GPS accuracy", "Advanced training metrics", "Multi-week battery life"],
    cons: ["Expensive", "Complex interface", "Bulky design"],
    author: "Tech Reviewer",
    readTime: "13 min read",
    category: "Fitness"
  },
  {
    id: 4,
    title: "Fitbit Charge 6: Budget Fitness King",
    brand: "Fitbit",
    model: "Charge 6",
    price: "$159",
    rating: 4.4,
    image: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxGaXRiaXQlMjBmaXRuZXNzJTIwdHJhY2tlcnxlbnwxfHx8fDE3NTgyMTkyODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Fitbit's latest fitness tracker offers excellent value with comprehensive health monitoring at an affordable price...",
    pros: ["Excellent value", "Great fitness tracking", "Week-long battery"],
    cons: ["Limited smart features", "Small screen", "Basic design"],
    author: "David Kim",
    readTime: "7 min read",
    category: "Fitness Tracker"
  }
];

const buyingGuides = [
  {
    id: 1,
    title: "Best Fitness Trackers Under $200",
    description: "Affordable wearables for health monitoring",
    icon: DollarSign,
    color: "bg-green-500"
  },
  {
    id: 2,
    title: "Premium Smartwatch Guide",
    description: "High-end wearables worth the investment",
    icon: Award,
    color: "bg-purple-500"
  },
  {
    id: 3,
    title: "Running Watch Essentials",
    description: "Best GPS watches for serious runners",
    icon: Activity,
    color: "bg-red-500"
  },
  {
    id: 4,
    title: "Health Monitoring Guide",
    description: "Wearables for comprehensive health tracking",
    icon: Heart,
    color: "bg-pink-500"
  },
  {
    id: 5,
    title: "Battery Life Champions",
    description: "Wearables with the longest battery life",
    icon: Zap,
    color: "bg-blue-500"
  }
];

interface WearablesPageProps {
  onBack: () => void;
}

export function WearablesPage({ onBack }: WearablesPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredReviews = wearableReviews.filter(review => {
    const matchesSearch = review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === "all" || review.brand.toLowerCase() === selectedBrand;
    const matchesCategory = selectedCategory === "all" || review.category.toLowerCase().replace(" ", "") === selectedCategory;
    
    return matchesSearch && matchesBrand && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Wearables & Smartwatches</h1>
                <p className="text-sm text-muted-foreground">Latest wearable tech reviews and guides</p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              {wearableReviews.length} Reviews
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="reviews" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reviews">Latest Reviews</TabsTrigger>
            <TabsTrigger value="guides">Buying Guides</TabsTrigger>
            <TabsTrigger value="comparisons">Comparisons</TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-8">
            {/* Filters */}
            <div className="flex flex-col md:flex-row gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search wearables..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedBrand} onValueChange={setSelectedBrand}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  <SelectItem value="apple">Apple</SelectItem>
                  <SelectItem value="samsung">Samsung</SelectItem>
                  <SelectItem value="garmin">Garmin</SelectItem>
                  <SelectItem value="fitbit">Fitbit</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="smartwatch">Smartwatch</SelectItem>
                  <SelectItem value="fitness">Fitness</SelectItem>
                  <SelectItem value="fitnesstracker">Fitness Tracker</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Reviews Grid */}
            <div className="grid lg:grid-cols-2 gap-8">
              {filteredReviews.map((review, index) => (
                <Card key={review.id} className={`overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1 ${index === 0 ? 'lg:col-span-2' : ''}`}>
                  <div className={`${index === 0 ? 'aspect-[16/9]' : 'aspect-[4/3]'} relative overflow-hidden`}>
                    <ImageWithFallback 
                      src={review.image}
                      alt={review.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className="bg-black/80 text-white">
                        {review.brand}
                      </Badge>
                      <Badge variant="secondary">
                        {review.category}
                      </Badge>
                      {review.featured && (
                        <Badge className="bg-red-500 text-white">
                          Featured
                        </Badge>
                      )}
                    </div>
                    <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {review.price}
                    </div>
                  </div>
                  <CardContent className={`${index === 0 ? 'p-8' : 'p-6'}`}>
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${
                              i < Math.floor(review.rating) 
                                ? 'fill-yellow-400 text-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium">{review.rating}/5</span>
                    </div>
                    <h3 className={`${index === 0 ? 'text-2xl' : 'text-lg'} font-semibold mb-3 group-hover:text-primary transition-colors`}>
                      {review.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 line-clamp-2">{review.excerpt}</p>
                    
                    {/* Pros & Cons */}
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <h5 className="text-sm font-medium text-green-600 mb-2">Pros</h5>
                        <ul className="text-xs space-y-1">
                          {review.pros.slice(0, 2).map((pro, i) => (
                            <li key={i} className="text-muted-foreground">• {pro}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-red-600 mb-2">Cons</h5>
                        <ul className="text-xs space-y-1">
                          {review.cons.slice(0, 2).map((con, i) => (
                            <li key={i} className="text-muted-foreground">• {con}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{review.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{review.readTime}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">Read Full Review</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guides" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold mb-2">Wearable Buying Guides</h2>
              <p className="text-muted-foreground">Expert advice to help you choose the perfect wearable device</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {buyingGuides.map((guide) => {
                const IconComponent = guide.icon;
                return (
                  <Card key={guide.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                    <CardContent className="p-6 text-center">
                      <div className={`${guide.color} text-white rounded-full p-4 w-16 h-16 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <IconComponent className="h-8 w-8" />
                      </div>
                      <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                        {guide.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        {guide.description}
                      </p>
                      <Button variant="outline" size="sm">Read Guide</Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="comparisons">
            <div className="text-center py-16">
              <h2 className="text-2xl font-semibold mb-2">Wearable Comparisons</h2>
              <p className="text-muted-foreground mb-8">Coming soon - detailed smartwatch and fitness tracker comparisons</p>
              <Button>Request a Comparison</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}