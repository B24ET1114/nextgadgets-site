import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { 
  ArrowLeft,
  Search,
  Home,
  FileQuestion,
  RefreshCw
} from "lucide-react";

interface NotFoundPageProps {
  onBack: () => void;
  onNavigate?: (page: string) => void;
}

export function NotFoundPage({ onBack, onNavigate }: NotFoundPageProps) {
  const popularPages = [
    { name: "Latest Reviews", key: "home", icon: Home },
    { name: "Smartphones", key: "smartphones", icon: Search },
    { name: "Laptops", key: "laptops", icon: Search },
    { name: "Gaming", key: "gaming", icon: Search },
    { name: "Buying Guides", key: "buyingguides", icon: Search },
    { name: "About Us", key: "about", icon: Search }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Page Not Found</h1>
                <p className="text-sm text-muted-foreground">Error 404</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-2xl mx-auto text-center">
          {/* 404 Illustration */}
          <div className="mb-8">
            <FileQuestion className="h-32 w-32 text-muted-foreground mx-auto mb-6" />
            <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
            <h2 className="text-2xl font-semibold mb-4">Page Not Found</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Oops! The page you're looking for doesn't exist. It might have been moved, deleted, 
              or you entered the wrong URL.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button onClick={() => onNavigate?.("home")} className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Go to Homepage
            </Button>
            <Button variant="outline" onClick={() => window.location.reload()} className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Refresh Page
            </Button>
            <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Go Back
            </Button>
          </div>

          {/* Popular Pages */}
          <Card>
            <CardContent className="p-8">
              <h3 className="text-lg font-semibold mb-6">Popular Pages</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {popularPages.map((page) => {
                  const IconComponent = page.icon;
                  return (
                    <Button
                      key={page.key}
                      variant="ghost"
                      onClick={() => onNavigate?.(page.key)}
                      className="justify-start h-auto p-4"
                    >
                      <IconComponent className="h-4 w-4 mr-3" />
                      {page.name}
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Help Text */}
          <div className="mt-12 p-6 bg-muted/30 rounded-lg">
            <h4 className="font-semibold mb-2">Need Help?</h4>
            <p className="text-sm text-muted-foreground">
              If you think this is a mistake or you're having trouble finding what you're looking for, 
              please <button 
                onClick={() => onNavigate?.("contact")} 
                className="text-primary hover:underline font-medium"
              >
                contact our support team
              </button> and we'll be happy to help.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}