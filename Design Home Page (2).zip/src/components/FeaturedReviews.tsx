import { memo, useState, useEffect } from "react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Star, Clock, User, TrendingUp, Eye, Heart, Share2, BookOpen, Sparkles, Zap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const featuredReviews = [
  {
    id: 1,
    title: "iPhone 15 Pro Max - The Ultimate Camera Phone?",
    excerpt: "Apple's latest flagship brings impressive camera improvements and titanium build quality...",
    image: "https://images.unsplash.com/photo-1726836584814-3c279642218b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHBob25lJTIwZGV2aWNlJTIwbG9nbyUyMG1vZGVybnxlbnwxfHx8fDE3NTgzMDUxMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.8,
    category: "Smartphones",
    author: "NextGadgets Team",
    readTime: "8 min read",
    featured: true,
    views: "127K",
    likes: "3.2K",
    isNew: true,
    color: "from-blue-500 to-blue-600"
  },
  {
    id: 2,
    title: "MacBook Pro M3 - Performance Revolution",
    excerpt: "The new M3 chip brings unprecedented performance to Apple's professional laptop lineup...",
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZSUyMG1vZGVybnxlbnwxfHx8fDE3NTgzMDUxMTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.9,
    category: "Laptops",
    author: "NextGadgets Team",
    readTime: "12 min read",
    views: "89K",
    likes: "2.1K",
    color: "from-green-500 to-green-600"
  },
  {
    id: 3,
    title: "Sony WH-1000XM5 - Best Noise Cancelling?",
    excerpt: "Sony's latest flagship headphones promise industry-leading noise cancellation and sound quality...",
    image: "https://images.unsplash.com/photo-1737885197886-9e34a03ad226?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lcyUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDUxMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    category: "Audio",
    author: "NextGadgets Team",
    readTime: "6 min read",
    views: "64K",
    likes: "1.8K",
    color: "from-purple-500 to-purple-600"
  }
];

interface FeaturedReviewsProps {
  onNavigate?: (page: string) => void;
  onViewReview?: (reviewId: string) => void;
}

const StarRating = memo(({ rating }: { rating: number }) => (
  <div className="flex group">
    {[...Array(5)].map((_, i) => (
      <Star 
        key={i} 
        className={`h-4 w-4 transition-all duration-300 ${
          i < Math.floor(rating) 
            ? 'fill-yellow-400 text-yellow-400 group-hover:scale-110 group-hover:rotate-12' 
            : 'text-gray-300'
        }`}
        style={{ animationDelay: `${i * 0.1}s` }}
      />
    ))}
  </div>
));

const SmallStarRating = memo(({ rating }: { rating: number }) => (
  <div className="flex group">
    {[...Array(5)].map((_, i) => (
      <Star 
        key={i} 
        className={`h-3 w-3 transition-all duration-300 ${
          i < Math.floor(rating) 
            ? 'fill-yellow-400 text-yellow-400 group-hover:scale-110' 
            : 'text-gray-300'
        }`} 
        style={{ animationDelay: `${i * 0.05}s` }}
      />
    ))}
  </div>
));

export const FeaturedReviews = memo(function FeaturedReviews({ onNavigate, onViewReview }: FeaturedReviewsProps) {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const [likedReviews, setLikedReviews] = useState<Set<number>>(new Set());

  const handleLike = (reviewId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const newLiked = new Set(likedReviews);
    if (newLiked.has(reviewId)) {
      newLiked.delete(reviewId);
    } else {
      newLiked.add(reviewId);
    }
    setLikedReviews(newLiked);
  };

  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Enhanced Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/5 to-background"></div>
      
      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-32 left-20 w-16 h-16 bg-gradient-to-br from-blue-500/20 to-blue-400/10 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-40 right-24 w-20 h-20 bg-gradient-to-br from-purple-500/20 to-purple-400/10 rounded-full blur-lg animate-pulse" style={{ animationDelay: '1s' }}></div>
        <Sparkles className="absolute top-20 right-1/4 h-6 w-6 text-primary/30 animate-pulse" style={{ animationDelay: '0.5s' }} />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-6 glass hover-scale interactive animate-fade-in-up border border-primary/20 bg-gradient-to-r from-primary/10 to-primary/5 badge-text-safe">
            <TrendingUp className="h-4 w-4 mr-2 animate-pulse" />
            <span className="text-primary force-primary">
              Featured Reviews
            </span>
          </Badge>
          <h2 className="text-4xl md:text-6xl mb-6 animate-fade-in-up text-foreground force-visible" style={{ animationDelay: '0.2s' }}>
            Latest In-Depth Reviews
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto animate-fade-in-up leading-relaxed" style={{ animationDelay: '0.4s' }}>
            Our expert team tests and reviews the latest gadgets to help you make informed purchasing decisions with comprehensive analysis and real-world testing.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-10">
          {/* Featured Review - Large */}
          <div className="lg:col-span-2 animate-fade-in-left" style={{ animationDelay: '0.6s' }}>
            <Card 
              className="overflow-hidden group glass-futuristic hover-lift-futuristic transition-all duration-700 interactive cursor-pointer relative border-0"
              onClick={() => onViewReview?.(featuredReviews[0].id.toString())}
              onMouseEnter={() => setHoveredCard(featuredReviews[0].id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div className="aspect-[16/9] relative overflow-hidden">
                <ImageWithFallback 
                  src={featuredReviews[0].image}
                  alt={featuredReviews[0].title}
                  className="w-full h-full object-cover group-hover:scale-110 group-hover:brightness-110 transition-all duration-700"
                />
                
                {/* Enhanced overlays */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className={`absolute inset-0 bg-gradient-to-br ${featuredReviews[0].color}/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
                
                {/* Category Badge */}
                <Badge className={`absolute top-6 left-6 glass-premium border-0 bg-gradient-to-r ${featuredReviews[0].color} text-white hover-scale animate-fade-in-up`}>
                  <Sparkles className="h-3 w-3 mr-1" />
                  {featuredReviews[0].category}
                </Badge>
                
                {/* New Badge */}
                {featuredReviews[0].isNew && (
                  <Badge className="absolute top-6 right-6 bg-gradient-to-r from-green-500 to-green-600 text-white border-0 animate-pulse">
                    <Zap className="h-3 w-3 mr-1" />
                    New
                  </Badge>
                )}
                
                {/* Interactive Action Buttons */}
                <div className="absolute bottom-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="glass-premium text-white hover:text-red-400 transition-colors duration-300"
                    onClick={(e) => handleLike(featuredReviews[0].id, e)}
                  >
                    <Heart className={`h-4 w-4 ${likedReviews.has(featuredReviews[0].id) ? 'fill-red-400 text-red-400' : ''}`} />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="glass-premium text-white hover:text-blue-400 transition-colors duration-300"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Scan Line Effect */}
                <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-primary to-transparent translate-y-0 group-hover:translate-y-full transition-transform duration-1000 ease-out"></div>
              </div>
              
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <StarRating rating={featuredReviews[0].rating} />
                    <span className="font-semibold text-foreground force-visible">
                      {featuredReviews[0].rating}/5
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Eye className="h-4 w-4" />
                      <span>{featuredReviews[0].views}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Heart className="h-4 w-4" />
                      <span>{featuredReviews[0].likes}</span>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-2xl mb-4 group-hover:text-primary transition-all duration-500 force-visible">
                  {featuredReviews[0].title}
                </h3>
                
                <p className="text-muted-foreground mb-6 leading-relaxed">{featuredReviews[0].excerpt}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4" />
                      <span>{featuredReviews[0].author}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4" />
                      <span>{featuredReviews[0].readTime}</span>
                    </div>
                  </div>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-x-4 group-hover:translate-x-0 hover-scale"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <BookOpen className="h-4 w-4 mr-2" />
                    Read More
                  </Button>
                </div>
              </CardContent>
              
              {/* Glow Effect */}
              <div className={`absolute inset-0 rounded-xl bg-gradient-to-br ${featuredReviews[0].color}/30 blur-2xl opacity-0 group-hover:opacity-30 transition-opacity duration-700 scale-110 -z-10`}></div>
            </Card>
          </div>

          {/* Enhanced Side Reviews */}
          <div className="space-y-8 animate-fade-in-right" style={{ animationDelay: '0.8s' }}>
            {featuredReviews.slice(1).map((review, index) => (
              <Card 
                key={review.id} 
                className="overflow-hidden group glass-futuristic hover-lift-futuristic transition-all duration-700 interactive cursor-pointer relative border-0" 
                style={{ animationDelay: `${1 + index * 0.2}s` }}
                onClick={() => onViewReview?.(review.id.toString())}
                onMouseEnter={() => setHoveredCard(review.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <div className="aspect-[4/3] relative overflow-hidden">
                  <ImageWithFallback 
                    src={review.image}
                    alt={review.title}
                    className="w-full h-full object-cover group-hover:scale-110 group-hover:brightness-110 transition-all duration-700"
                  />
                  
                  {/* Enhanced overlays */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div className={`absolute inset-0 bg-gradient-to-br ${review.color}/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
                  
                  {/* Category Badge */}
                  <Badge className={`absolute top-4 left-4 text-xs glass-premium border-0 bg-gradient-to-r ${review.color} text-white hover-scale`}>
                    {review.category}
                  </Badge>
                  
                  {/* Interactive Elements */}
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-500">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="glass-premium text-white hover:text-red-400 p-2"
                      onClick={(e) => handleLike(review.id, e)}
                    >
                      <Heart className={`h-3 w-3 ${likedReviews.has(review.id) ? 'fill-red-400 text-red-400' : ''}`} />
                    </Button>
                  </div>
                  
                  {/* Scan Line Effect */}
                  <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-primary to-transparent translate-y-0 group-hover:translate-y-full transition-transform duration-800 ease-out"></div>
                </div>
                
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <SmallStarRating rating={review.rating} />
                      <span className="text-sm font-semibold text-foreground force-visible">
                        {review.rating}/5
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Eye className="h-3 w-3" />
                        <span>{review.views}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Heart className="h-3 w-3" />
                        <span>{review.likes}</span>
                      </div>
                    </div>
                  </div>
                  
                  <h4 className="font-semibold mb-3 group-hover:text-primary transition-all duration-500 line-clamp-2 leading-tight force-visible">
                    {review.title}
                  </h4>
                  
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2 leading-relaxed">{review.excerpt}</p>
                  
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center space-x-2">
                      <User className="h-3 w-3" />
                      <span>{review.author}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-3 w-3" />
                      <span>{review.readTime}</span>
                    </div>
                  </div>
                </CardContent>
                
                {/* Glow Effect */}
                <div className={`absolute inset-0 rounded-xl bg-gradient-to-br ${review.color}/30 blur-xl opacity-0 group-hover:opacity-30 transition-opacity duration-700 scale-110 -z-10`}></div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});