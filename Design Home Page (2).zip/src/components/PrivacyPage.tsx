import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { ArrowLeft, Shield, Eye, Database, UserCheck } from "lucide-react";

interface PrivacyPageProps {
  onBack: () => void;
}

export function PrivacyPage({ onBack }: PrivacyPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Privacy Policy</h1>
                <p className="text-sm text-muted-foreground">How we protect your data</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
            <p className="text-lg text-muted-foreground">
              Last updated: January 18, 2025
            </p>
          </div>

          {/* Quick Overview */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <Card className="text-center">
              <CardContent className="p-6">
                <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Data Protection</h3>
                <p className="text-sm text-muted-foreground">We use industry-standard security measures</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <Eye className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Transparency</h3>
                <p className="text-sm text-muted-foreground">Clear information about data usage</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <Database className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Minimal Data</h3>
                <p className="text-sm text-muted-foreground">We only collect what's necessary</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <UserCheck className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Your Rights</h3>
                <p className="text-sm text-muted-foreground">Full control over your personal data</p>
              </CardContent>
            </Card>
          </div>

          {/* Privacy Policy Content */}
          <div className="prose prose-gray dark:prose-invert max-w-none">
            <Card className="mb-8">
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">Information We Collect</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    <strong>Personal Information:</strong> When you subscribe to our newsletter or contact us, 
                    we may collect your name and email address.
                  </p>
                  <p>
                    <strong>Usage Data:</strong> We collect information about how you interact with our website, 
                    including pages visited, time spent, and referring sources.
                  </p>
                  <p>
                    <strong>Device Information:</strong> We automatically collect certain information about your 
                    device, including IP address, browser type, and operating system.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">How We Use Your Information</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>We use the information we collect to:</p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li>Provide and improve our content and services</li>
                    <li>Send you newsletters and updates (only if you've opted in)</li>
                    <li>Respond to your inquiries and provide customer support</li>
                    <li>Analyze website usage to improve user experience</li>
                    <li>Comply with legal obligations</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">Information Sharing</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    We do not sell, trade, or otherwise transfer your personal information to third parties 
                    without your consent, except as described in this policy.
                  </p>
                  <p>We may share information with:</p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li>Service providers who assist in operating our website</li>
                    <li>Analytics services to understand website usage</li>
                    <li>Legal authorities when required by law</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">Cookies and Tracking</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    We use cookies and similar tracking technologies to enhance your browsing experience 
                    and analyze website traffic. You can control cookie settings through your browser preferences.
                  </p>
                  <p>Types of cookies we use:</p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li><strong>Essential cookies:</strong> Required for basic website functionality</li>
                    <li><strong>Analytics cookies:</strong> Help us understand how visitors use our site</li>
                    <li><strong>Preference cookies:</strong> Remember your settings and preferences</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">Your Rights</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>You have the right to:</p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li>Access the personal information we hold about you</li>
                    <li>Request correction of inaccurate information</li>
                    <li>Request deletion of your personal information</li>
                    <li>Opt-out of marketing communications</li>
                    <li>Data portability (receive your data in a structured format)</li>
                  </ul>
                  <p>
                    To exercise these rights, please contact us at nextgadgets@tutamail.com.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">Data Security</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    We implement appropriate technical and organizational security measures to protect 
                    your personal information against unauthorized access, alteration, disclosure, or destruction.
                  </p>
                  <p>Security measures include:</p>
                  <ul className="list-disc list-inside space-y-2 ml-4">
                    <li>SSL encryption for data transmission</li>
                    <li>Regular security assessments</li>
                    <li>Limited access to personal information</li>
                    <li>Secure data storage practices</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8">
                <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
                <div className="space-y-4 text-sm leading-relaxed">
                  <p>
                    If you have any questions about this Privacy Policy or our data practices, 
                    please contact us at:
                  </p>
                  <div className="bg-muted/30 p-4 rounded-lg">
                    <p><strong>Email:</strong> nextgadgets@tutamail.com</p>
                    <p><strong>Address:</strong> NextGadgets.tech, Maharashtra, India</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}