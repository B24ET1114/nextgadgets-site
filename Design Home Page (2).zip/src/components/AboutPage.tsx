import { Button } from "./ui/button";
import { 
  ArrowLeft,
  Mail
} from "lucide-react";

interface AboutPageProps {
  onBack: () => void;
}

export function AboutPage({ onBack }: AboutPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">About NextGadgets.tech</h1>
                <p className="text-sm text-muted-foreground">Our mission and team</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold mb-6">About Me</h1>
          <div className="max-w-4xl mx-auto">
            <div className="bg-muted/30 rounded-lg p-8 text-left">
              <p className="text-lg leading-relaxed mb-4">
                Hi, I'm <strong>Pranav Kelapure</strong>, an Electronics and Telecommunication engineering student from Pune, India. I'm passionate about technology, gadgets, and innovation.
              </p>
              <p className="text-lg leading-relaxed mb-4">
                I started nextgadgets.tech to share my interest in the latest devices — from smartphones and laptops to smart wearables and future-ready tech. My goal is to make technology easy to understand while also building my own hands-on experience in web development and engineering projects.
              </p>
              <p className="text-lg leading-relaxed mb-4">
                Beyond gadgets, I enjoy learning, experimenting, and creating. Whether it's coding, exploring new tools, or working on real-world projects, I love the process of turning ideas into reality.
              </p>
              <p className="text-lg leading-relaxed">
                Through this platform, I want to connect with like-minded tech enthusiasts, share insights, and grow my skills while preparing myself for bigger opportunities in the world of innovation.
              </p>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <div className="bg-muted/30 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-semibold mb-4">Get In Touch</h2>
          <p className="text-muted-foreground mb-6">
            Have questions, suggestions, or want to collaborate? I'd love to hear from you.
          </p>
          <div className="flex justify-center mb-6">
            <Button variant="outline" size="sm">
              <Mail className="h-4 w-4 mr-2" />
              Email Me
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            For review requests and collaborations: nextgadgets@tutamail.com
          </p>
        </div>
      </div>
    </div>
  );
}