import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Separator } from "./ui/separator";
import { 
  ArrowLeft,
  Star,
  ThumbsUp,
  ThumbsDown,
  Share,
  Bookmark,
  Calendar,
  Clock,
  User,
  Award,
  TrendingUp,
  CheckCircle,
  XCircle,
  Camera,
  Battery,
  Cpu,
  Smartphone
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface ReviewPageProps {
  onBack: () => void;
  productId?: string;
}

// Sample review data - in real app this would come from props/API
const sampleReview = {
  id: "iphone-15-pro-max",
  title: "iPhone 15 Pro Max Review: The Camera King",
  subtitle: "Apple's flagship delivers exceptional camera performance and titanium build quality",
  category: "Smartphones",
  brand: "Apple",
  model: "iPhone 15 Pro Max",
  price: "$1,199",
  rating: 4.8,
  reviewDate: "2025-01-15",
  author: {
    name: "Tech Reviewer",
    bio: "Senior Hardware Reviewer with 8+ years covering mobile technology",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW4lMjBwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdHxlbnwxfHx8fDE3NTgyMTk0NjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  images: [
    "https://images.unsplash.com/photo-1743677221330-9886caa74fcc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpUGhvbmUlMjAxNSUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzU4MjE4ODQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpUGhvbmUlMjBjYW1lcmF8ZW58MXx8fHwxNzU4MjE5NTg5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  ],
  specs: {
    "Display": "6.7-inch Super Retina XDR OLED",
    "Processor": "A17 Pro chip",
    "Camera": "48MP Main + 12MP Ultra Wide + 12MP Telephoto",
    "Battery": "Up to 29 hours video playback",
    "Storage": "256GB / 512GB / 1TB",
    "Weight": "221 grams"
  },
  scores: {
    "Design & Build": 9.0,
    "Display": 9.5,
    "Performance": 9.8,
    "Camera": 9.2,
    "Battery Life": 8.5,
    "Value": 7.8
  },
  pros: [
    "Exceptional camera system with improved zoom",
    "Premium titanium build quality",
    "Outstanding A17 Pro performance",
    "Excellent display brightness and color accuracy",
    "Improved battery life over predecessor"
  ],
  cons: [
    "Very expensive starting price",
    "Lightning to USB-C transition may require new accessories",
    "Heavy weight for extended use",
    "Limited AI features compared to competitors"
  ],
  verdict: "The iPhone 15 Pro Max represents Apple's most refined flagship yet, with exceptional camera capabilities and premium build quality that justify the premium price for those who demand the best.",
  readTime: "12 min read"
};

export function ReviewPage({ onBack, productId }: ReviewPageProps) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [userRating, setUserRating] = useState(0);

  const review = sampleReview; // In real app, fetch based on productId

  const overallScore = Object.values(review.scores).reduce((a, b) => a + b, 0) / Object.values(review.scores).length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">{review.model}</h1>
                <p className="text-sm text-muted-foreground">In-depth review</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Share className="h-4 w-4 mr-2" />
                Share
              </Button>
              <Button 
                variant={isBookmarked ? "default" : "outline"} 
                size="sm"
                onClick={() => setIsBookmarked(!isBookmarked)}
              >
                <Bookmark className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Article Header */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="secondary">{review.category}</Badge>
              <Badge className="bg-green-500">{review.brand}</Badge>
            </div>
            
            <h1 className="text-3xl font-bold mb-4">{review.title}</h1>
            <p className="text-xl text-muted-foreground mb-6">{review.subtitle}</p>
            
            {/* Rating and Meta */}
            <div className="flex flex-wrap items-center gap-6 mb-6">
              <div className="flex items-center gap-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`h-5 w-5 ${
                        i < Math.floor(review.rating) 
                          ? 'fill-yellow-400 text-yellow-400' 
                          : 'text-gray-300'
                      }`} 
                    />
                  ))}
                </div>
                <span className="font-semibold">{review.rating}/5</span>
              </div>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  <span>{review.author.name}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>{new Date(review.reviewDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>{review.readTime}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {/* Left Column - Images and Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Image Gallery */}
              <Card>
                <CardContent className="p-0">
                  <div className="aspect-video relative overflow-hidden rounded-t-lg">
                    <ImageWithFallback 
                      src={review.images[selectedImage]}
                      alt={review.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded text-sm">
                      {review.price}
                    </div>
                  </div>
                  {review.images.length > 1 && (
                    <div className="p-4 flex gap-2 overflow-x-auto">
                      {review.images.map((image, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedImage(index)}
                          className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 ${
                            selectedImage === index ? 'border-primary' : 'border-transparent'
                          }`}
                        >
                          <ImageWithFallback 
                            src={image}
                            alt={`${review.title} ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Review Content */}
              <Card>
                <CardContent className="p-8">
                  <h2 className="text-xl font-semibold mb-4">Our Verdict</h2>
                  <p className="text-lg leading-relaxed mb-6">{review.verdict}</p>
                  
                  <Separator className="my-6" />
                  
                  <h2 className="text-xl font-semibold mb-4">What We Liked</h2>
                  <ul className="space-y-3 mb-6">
                    {review.pros.map((pro, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span>{pro}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <h2 className="text-xl font-semibold mb-4">What Could Be Better</h2>
                  <ul className="space-y-3">
                    {review.cons.map((con, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                        <span>{con}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Author Bio */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <ImageWithFallback 
                      src={review.author.avatar}
                      alt={review.author.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div>
                      <h3 className="font-semibold mb-1">{review.author.name}</h3>
                      <p className="text-sm text-muted-foreground">{review.author.bio}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Specs and Scores */}
            <div className="space-y-6">
              {/* Overall Score */}
              <Card>
                <CardContent className="p-6 text-center">
                  <Award className="h-12 w-12 text-primary mx-auto mb-4" />
                  <div className="text-3xl font-bold text-primary mb-2">
                    {overallScore.toFixed(1)}
                  </div>
                  <p className="text-sm text-muted-foreground">Overall Score</p>
                </CardContent>
              </Card>

              {/* Detailed Scores */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Detailed Scores</h3>
                  <div className="space-y-4">
                    {Object.entries(review.scores).map(([category, score]) => (
                      <div key={category}>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm">{category}</span>
                          <span className="text-sm font-medium">{score}/10</span>
                        </div>
                        <Progress value={score * 10} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Key Specs */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Key Specifications</h3>
                  <div className="space-y-3">
                    {Object.entries(review.specs).map(([spec, value]) => (
                      <div key={spec} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{spec}:</span>
                        <span className="font-medium text-right flex-1 ml-2">{value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* User Rating */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Rate This Review</h3>
                  <div className="flex justify-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setUserRating(i + 1)}
                        className="p-1"
                      >
                        <Star 
                          className={`h-6 w-6 ${
                            i < userRating 
                              ? 'fill-yellow-400 text-yellow-400' 
                              : 'text-gray-300 hover:text-yellow-400'
                          }`} 
                        />
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <ThumbsUp className="h-4 w-4 mr-1" />
                      Helpful
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <ThumbsDown className="h-4 w-4 mr-1" />
                      Not Helpful
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}