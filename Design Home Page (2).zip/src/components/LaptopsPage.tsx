import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Search, 
  Star, 
  Clock, 
  User, 
  ArrowLeft,
  TrendingUp,
  Award,
  DollarSign,
  Zap,
  Monitor,
  Cpu,
  HardDrive,
  Laptop
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const laptopReviews = [
  {
    id: 1,
    title: "MacBook Pro M3 Max: Creative Powerhouse",
    brand: "Apple",
    model: "MacBook Pro 16-inch M3 Max",
    price: "$3,999",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Apple's flagship laptop delivers unmatched performance for creative professionals with the revolutionary M3 Max chip and stunning Liquid Retina XDR display...",
    fullReview: "The MacBook Pro 16-inch with M3 Max represents the pinnacle of laptop performance for creative professionals. The M3 Max chip delivers unprecedented performance in video editing, 3D rendering, and other demanding creative tasks. The Liquid Retina XDR display offers exceptional color accuracy and brightness, perfect for professional photo and video work. Battery life remains impressive despite the powerful hardware, easily lasting a full workday of intensive tasks.",
    specs: {
      processor: "Apple M3 Max (16-core CPU, 40-core GPU)",
      ram: "48GB/128GB Unified Memory",
      storage: "1TB/2TB/4TB/8TB SSD",
      display: "16.2-inch Liquid Retina XDR (3456×2234)",
      ports: "3x Thunderbolt 4, HDMI, MagSafe 3, SD card",
      battery: "22 hours video playback",
      weight: "4.7 lbs (2.15 kg)"
    },
    pros: ["Exceptional M3 Max performance", "Stunning XDR display", "Excellent battery life", "Premium build quality", "Silent operation"],
    cons: ["Extremely expensive", "Limited port selection", "Heavy weight", "Overkill for basic tasks"],
    author: "NextGadgets Team",
    readTime: "15 min read",
    category: "Creative",
    featured: true,
    score: {
      performance: 10.0,
      display: 9.8,
      battery: 9.0,
      build: 9.5,
      value: 6.0
    }
  },
  {
    id: 2,
    title: "Dell XPS 13 Plus: Windows Excellence",
    brand: "Dell",
    model: "XPS 13 Plus",
    price: "$1,299",
    rating: 4.6,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Dell's premium ultrabook combines stunning design with powerful Intel Core processors in an incredibly thin and light package...",
    fullReview: "The Dell XPS 13 Plus pushes the boundaries of ultrabook design with its edge-to-edge keyboard, invisible trackpad, and minimal bezels. The 13th Gen Intel Core processors provide excellent performance for productivity tasks, while the OLED display option offers vibrant colors and deep blacks. The premium build quality and attention to detail make this one of the most desirable Windows laptops available.",
    specs: {
      processor: "Intel Core i7-1360P (12-core)",
      ram: "16GB/32GB LPDDR5",
      storage: "512GB/1TB/2TB PCIe SSD",
      display: "13.4-inch OLED 3.5K (3456×2160)",
      ports: "2x Thunderbolt 4",
      battery: "12 hours mixed use",
      weight: "2.73 lbs (1.24 kg)"
    },
    pros: ["Stunning OLED display", "Premium build quality", "Excellent performance", "Ultra-portable", "Beautiful design"],
    cons: ["Limited port selection", "Expensive OLED option", "Keyboard takes adjustment", "Thermal throttling under load"],
    author: "NextGadgets Team",
    readTime: "12 min read",
    category: "Ultrabook",
    score: {
      performance: 8.5,
      display: 9.5,
      battery: 8.0,
      build: 9.0,
      value: 7.5
    }
  },
  {
    id: 3,
    title: "ASUS ROG Strix G16: Gaming Beast",
    brand: "ASUS",
    model: "ROG Strix G16",
    price: "$1,899",
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "ASUS delivers exceptional gaming performance with RTX 4070 graphics, high-refresh display, and advanced cooling in this gaming powerhouse...",
    fullReview: "The ROG Strix G16 is built for serious gaming with no compromises. The RTX 4070 graphics card handles all modern games at high settings, while the 165Hz QHD display delivers smooth, tear-free gaming. Advanced cooling keeps temperatures under control during extended gaming sessions. The Aura Sync RGB lighting adds gaming flair without being overly flashy.",
    specs: {
      processor: "Intel Core i7-13650HX (14-core)",
      ram: "16GB DDR5-4800",
      storage: "1TB PCIe 4.0 SSD",
      graphics: "NVIDIA GeForce RTX 4070 8GB",
      display: "16-inch QHD 165Hz (2560×1600)",
      ports: "3x USB-A, 1x USB-C, HDMI 2.1, Ethernet",
      battery: "6-8 hours general use",
      weight: "5.51 lbs (2.5 kg)"
    },
    pros: ["Excellent gaming performance", "High-refresh QHD display", "Advanced cooling", "Good port selection", "RGB lighting"],
    cons: ["Heavy and bulky", "Poor battery life", "Loud under load", "Plastic build quality"],
    author: "NextGadgets Team",
    readTime: "10 min read",
    category: "Gaming",
    score: {
      performance: 9.5,
      display: 9.0,
      battery: 6.0,
      build: 7.5,
      value: 8.5
    }
  },
  {
    id: 4,
    title: "Lenovo ThinkPad X1 Carbon: Business Elite",
    brand: "Lenovo",
    model: "ThinkPad X1 Carbon Gen 11",
    price: "$1,699",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "The gold standard for business laptops combines legendary ThinkPad durability with modern performance and security features...",
    fullReview: "The ThinkPad X1 Carbon continues the legendary ThinkPad tradition of excellence in business computing. The carbon fiber construction provides durability while keeping weight minimal. The legendary ThinkPad keyboard remains the best in the business for extended typing sessions. Military-grade testing ensures reliability in demanding environments, while modern security features protect sensitive business data.",
    specs: {
      processor: "Intel Core i7-1365U vPro (12-core)",
      ram: "16GB/32GB LPDDR5",
      storage: "512GB/1TB/2TB PCIe SSD",
      display: "14-inch WUXGA (1920×1200) or 2.8K OLED",
      ports: "2x Thunderbolt 4, 2x USB-A, HDMI 2.1",
      battery: "15+ hours productivity use",
      weight: "2.48 lbs (1.12 kg)"
    },
    pros: ["Exceptional keyboard", "Ultra-lightweight", "Military-grade durability", "Excellent battery life", "Security features"],
    cons: ["Expensive", "Basic integrated graphics", "Conservative design", "Limited gaming capability"],
    author: "NextGadgets Team",
    readTime: "11 min read",
    category: "Business",
    score: {
      performance: 8.0,
      display: 8.5,
      battery: 9.5,
      build: 9.8,
      value: 7.0
    }
  },
  {
    id: 5,
    title: "Microsoft Surface Laptop Studio 2: Creative Hybrid",
    brand: "Microsoft",
    model: "Surface Laptop Studio 2",
    price: "$2,399",
    rating: 4.3,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Microsoft's unique convertible design combines laptop performance with tablet versatility, perfect for creative professionals...",
    fullReview: "The Surface Laptop Studio 2 offers a unique form factor that transforms from laptop to studio canvas. The innovative hinge design allows the touchscreen to fold down for drawing and creative work. RTX 4060 graphics provide solid performance for creative applications, while the Surface Pen offers precise input for digital artists. The haptic feedback touchpad adds a premium touch to the user experience.",
    specs: {
      processor: "Intel Core i7-13700H (14-core)",
      ram: "16GB/32GB/64GB LPDDR5x",
      storage: "512GB/1TB/2TB PCIe SSD",
      graphics: "NVIDIA GeForce RTX 4060 8GB",
      display: "14.4-inch PixelSense Flow 2400×1600 120Hz",
      ports: "2x USB-C, 1x USB-A, Surface Connect",
      battery: "8-10 hours mixed use",
      weight: "4.0 lbs (1.8 kg)"
    },
    pros: ["Unique convertible design", "Excellent for creative work", "High-quality display", "Good performance", "Surface Pen support"],
    cons: ["Expensive", "Heavy for a convertible", "Limited ports", "Proprietary charging"],
    author: "NextGadgets Team",
    readTime: "9 min read",
    category: "Convertible",
    score: {
      performance: 8.5,
      display: 9.0,
      battery: 7.5,
      build: 8.5,
      value: 6.5
    }
  },
  {
    id: 6,
    title: "Acer Predator Helios 16: Budget Gaming Beast",
    brand: "Acer",
    model: "Predator Helios 16",
    price: "$1,399",
    rating: 4.2,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Acer delivers exceptional gaming performance at an affordable price point with RTX 4060 graphics and high-refresh display...",
    fullReview: "The Predator Helios 16 proves that excellent gaming performance doesn't have to break the bank. The RTX 4060 handles modern games at high settings with ease, while the 165Hz display ensures smooth gameplay. The cooling system keeps temperatures reasonable during gaming sessions. While the build quality isn't premium, it's solid enough for the price point.",
    specs: {
      processor: "Intel Core i7-13700HX (16-core)",
      ram: "16GB DDR5-4800",
      storage: "1TB PCIe Gen4 SSD",
      graphics: "NVIDIA GeForce RTX 4060 8GB",
      display: "16-inch WQXGA 165Hz (2560×1600)",
      ports: "3x USB-A, 1x USB-C, HDMI 2.1, Ethernet",
      battery: "5-6 hours general use",
      weight: "6.17 lbs (2.8 kg)"
    },
    pros: ["Great gaming performance", "Affordable price", "High-refresh display", "Good cooling", "Plenty of ports"],
    cons: ["Plastic build quality", "Poor battery life", "Heavy and thick", "Loud fans"],
    author: "NextGadgets Team",
    readTime: "8 min read",
    category: "Gaming",
    score: {
      performance: 8.5,
      display: 8.0,
      battery: 5.5,
      build: 6.5,
      value: 9.0
    }
  },
  {
    id: 7,
    title: "HP Spectre x360 16: Premium Convertible",
    brand: "HP",
    model: "Spectre x360 16",
    price: "$1,799",
    rating: 4.4,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "HP's premium convertible combines elegant design with versatile functionality and solid performance in a beautiful package...",
    fullReview: "The Spectre x360 16 exemplifies premium convertible design with its gem-cut aesthetics and robust 360-degree hinge. The OLED display option provides stunning visuals with perfect blacks and vibrant colors. The Intel Core H-series processor provides solid performance for both productivity and light creative work. The included stylus makes it excellent for note-taking and digital art.",
    specs: {
      processor: "Intel Core i7-13700H (14-core)",
      ram: "16GB/32GB LPDDR5",
      storage: "512GB/1TB/2TB PCIe SSD",
      display: "16-inch 3K+ OLED (3072×1920)",
      ports: "2x Thunderbolt 4, 1x USB-A, microSD",
      battery: "10-12 hours mixed use",
      weight: "4.45 lbs (2.02 kg)"
    },
    pros: ["Stunning OLED display", "Premium build quality", "Versatile convertible design", "Good performance", "Included stylus"],
    cons: ["Expensive OLED option", "Heavy for a convertible", "OLED battery drain", "Limited ports"],
    author: "NextGadgets Team",
    readTime: "10 min read",
    category: "Convertible",
    score: {
      performance: 8.0,
      display: 9.5,
      battery: 8.0,
      build: 9.0,
      value: 7.0
    }
  },
  {
    id: 8,
    title: "Framework Laptop 16: Modular Innovation",
    brand: "Framework",
    model: "Laptop 16",
    price: "$1,999",
    rating: 4.1,
    image: "https://images.unsplash.com/photo-1754928864131-21917af96dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsYXB0b3AlMjBjb21wdXRlciUyMGRldmljZXxlbnwxfHx8fDE3NTgzMDY4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    excerpt: "Framework's revolutionary modular design allows complete customization and upgradeability in a sustainable, repairable laptop...",
    fullReview: "The Framework Laptop 16 represents a revolutionary approach to laptop design with its fully modular and upgradeable architecture. Every component can be easily replaced or upgraded, from RAM and storage to the entire motherboard. The modular port system allows complete customization of connectivity options. While not the thinnest or lightest laptop, the repairability and upgradeability make it an excellent long-term investment.",
    specs: {
      processor: "AMD Ryzen 7 7840HS (8-core)",
      ram: "16GB/64GB DDR5 (upgradeable)",
      storage: "1TB PCIe Gen4 SSD (upgradeable)",
      graphics: "Radeon 780M / Optional dGPU module",
      display: "16-inch 2.5K (2560×1600)",
      ports: "Fully modular expansion cards",
      battery: "8-10 hours productivity",
      weight: "4.8 lbs (2.17 kg)"
    },
    pros: ["Fully modular design", "Completely repairable", "Upgradeable everything", "Sustainable approach", "Customizable ports"],
    cons: ["Thick and heavy", "Premium pricing", "Limited availability", "Assembly required"],
    author: "NextGadgets Team",
    readTime: "12 min read",
    category: "Innovative",
    score: {
      performance: 8.0,
      display: 8.0,
      battery: 8.0,
      build: 8.5,
      value: 8.0
    }
  }
];

const buyingGuides = [
  {
    id: 1,
    title: "Best Laptops Under $1000 (2025)",
    description: "Top budget laptops for students and professionals",
    icon: DollarSign,
    color: "bg-green-500"
  },
  {
    id: 2,
    title: "Gaming Laptop Buyer's Guide",
    description: "Everything you need to know about gaming laptops",
    icon: Zap,
    color: "bg-purple-500"
  },
  {
    id: 3,
    title: "Business Laptop Comparison",
    description: "Best laptops for professional work environments",
    icon: Award,
    color: "bg-blue-500"
  },
  {
    id: 4,
    title: "Creative Professional Laptops",
    description: "Best laptops for video editing and design work",
    icon: Monitor,
    color: "bg-red-500"
  },
  {
    id: 5,
    title: "Ultrabook Performance Guide",
    description: "Thin and light laptops with serious performance",
    icon: Cpu,
    color: "bg-orange-500"
  },
  {
    id: 6,
    title: "Storage and RAM Upgrade Guide",
    description: "How to upgrade your laptop's memory and storage",
    icon: HardDrive,
    color: "bg-indigo-500"
  }
];

interface LaptopsPageProps {
  onBack: () => void;
}

export function LaptopsPage({ onBack }: LaptopsPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedReview, setSelectedReview] = useState<any>(null);

  const filteredReviews = laptopReviews.filter(review => {
    const matchesSearch = review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === "all" || review.brand.toLowerCase() === selectedBrand;
    const matchesCategory = selectedCategory === "all" || review.category.toLowerCase() === selectedCategory;
    
    return matchesSearch && matchesBrand && matchesCategory;
  });

  if (selectedReview) {
    return (
      <div className="min-h-screen bg-background">
        <div className="border-b bg-background/95 backdrop-blur sticky top-0 z-40">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button variant="ghost" size="icon" onClick={() => setSelectedReview(null)}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Badge variant="secondary">Full Review</Badge>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="aspect-[16/9] relative overflow-hidden rounded-xl mb-8">
              <ImageWithFallback 
                src={selectedReview.image}
                alt={selectedReview.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <Badge className="bg-black/80 text-white">{selectedReview.brand}</Badge>
                <Badge variant="secondary">{selectedReview.category}</Badge>
              </div>
              <div className="absolute bottom-4 right-4 bg-black/80 text-white px-4 py-2 rounded-full font-medium">
                {selectedReview.price}
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-4">{selectedReview.title}</h1>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground mb-6">
                  <div className="flex items-center space-x-1">
                    <User className="h-4 w-4" />
                    <span>{selectedReview.author}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{selectedReview.readTime}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${
                            i < Math.floor(selectedReview.rating) 
                              ? 'fill-yellow-400 text-yellow-400' 
                              : 'text-gray-300'
                          }`} 
                        />
                      ))}
                    </div>
                    <span className="font-medium">{selectedReview.rating}/5</span>
                  </div>
                </div>
              </div>

              <div className="prose max-w-none">
                <p className="text-lg leading-relaxed text-muted-foreground">
                  {selectedReview.fullReview}
                </p>
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Performance Scores</h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(selectedReview.score).map(([category, score]) => (
                      <div key={category} className="text-center">
                        <div className="text-2xl font-bold text-primary mb-1">{score}</div>
                        <div className="text-sm text-muted-foreground capitalize">{category}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Technical Specifications</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {Object.entries(selectedReview.specs).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                        <span className="font-medium">{value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-green-600 mb-4">Pros</h3>
                    <ul className="space-y-2">
                      {selectedReview.pros.map((pro: string, i: number) => (
                        <li key={i} className="flex items-start space-x-2">
                          <span className="text-green-500 mt-1">+</span>
                          <span>{pro}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-red-600 mb-4">Cons</h3>
                    <ul className="space-y-2">
                      {selectedReview.cons.map((con: string, i: number) => (
                        <li key={i} className="flex items-start space-x-2">
                          <span className="text-red-500 mt-1">-</span>
                          <span>{con}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-background/95 backdrop-blur sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div>
                <h1 className="font-semibold">Laptop Reviews</h1>
                <p className="text-sm text-muted-foreground">Latest laptop reviews and guides</p>
              </div>
            </div>
            <Badge variant="secondary">
              <TrendingUp className="h-3 w-3 mr-1" />
              {laptopReviews.length} Reviews
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="reviews" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reviews">Latest Reviews</TabsTrigger>
            <TabsTrigger value="guides">Buying Guides</TabsTrigger>
            <TabsTrigger value="comparisons">Comparisons</TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-8">
            <div className="flex flex-col md:flex-row gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search laptops..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedBrand} onValueChange={setSelectedBrand}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Brands" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Brands</SelectItem>
                  <SelectItem value="apple">Apple</SelectItem>
                  <SelectItem value="dell">Dell</SelectItem>
                  <SelectItem value="asus">ASUS</SelectItem>
                  <SelectItem value="lenovo">Lenovo</SelectItem>
                  <SelectItem value="microsoft">Microsoft</SelectItem>
                  <SelectItem value="acer">Acer</SelectItem>
                  <SelectItem value="hp">HP</SelectItem>
                  <SelectItem value="framework">Framework</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                  <SelectItem value="ultrabook">Ultrabook</SelectItem>
                  <SelectItem value="gaming">Gaming</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="convertible">Convertible</SelectItem>
                  <SelectItem value="innovative">Innovative</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {filteredReviews.map((review, index) => (
                <Card 
                  key={review.id} 
                  className={`overflow-hidden group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1 ${index === 0 ? 'lg:col-span-2' : ''}`}
                  onClick={() => setSelectedReview(review)}
                >
                  <div className={`${index === 0 ? 'aspect-[16/9]' : 'aspect-[4/3]'} relative overflow-hidden`}>
                    <ImageWithFallback 
                      src={review.image}
                      alt={review.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <Badge className="bg-black/80 text-white">{review.brand}</Badge>
                      <Badge variant="secondary">{review.category}</Badge>
                      {review.featured && (
                        <Badge className="bg-red-500 text-white">Featured</Badge>
                      )}
                    </div>
                    <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {review.price}
                    </div>
                  </div>
                  <CardContent className={`${index === 0 ? 'p-8' : 'p-6'}`}>
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${
                              i < Math.floor(review.rating) 
                                ? 'fill-yellow-400 text-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium">{review.rating}/5</span>
                    </div>
                    <h3 className={`${index === 0 ? 'text-2xl' : 'text-lg'} font-semibold mb-3 group-hover:text-primary transition-colors`}>
                      {review.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 line-clamp-2">{review.excerpt}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <h5 className="text-sm font-medium text-green-600 mb-2">Pros</h5>
                        <ul className="text-xs space-y-1">
                          {review.pros.slice(0, 2).map((pro, i) => (
                            <li key={i} className="text-muted-foreground">• {pro}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-red-600 mb-2">Cons</h5>
                        <ul className="text-xs space-y-1">
                          {review.cons.slice(0, 2).map((con, i) => (
                            <li key={i} className="text-muted-foreground">• {con}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{review.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{review.readTime}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">Read Review</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guides" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold mb-2">Laptop Buying Guides</h2>
              <p className="text-muted-foreground">Expert advice for choosing the perfect laptop</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {buyingGuides.map((guide) => {
                const IconComponent = guide.icon;
                return (
                  <Card key={guide.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer hover:-translate-y-1">
                    <CardContent className="p-6 text-center">
                      <div className={`${guide.color} text-white rounded-full p-4 w-16 h-16 mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <IconComponent className="h-8 w-8" />
                      </div>
                      <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                        {guide.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        {guide.description}
                      </p>
                      <Button variant="outline" size="sm">Read Guide</Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="comparisons">
            <div className="text-center py-16">
              <Laptop className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-2xl font-semibold mb-2">Laptop Comparisons</h2>
              <p className="text-muted-foreground mb-8">Detailed head-to-head comparisons coming soon</p>
              <Button>Request a Comparison</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}